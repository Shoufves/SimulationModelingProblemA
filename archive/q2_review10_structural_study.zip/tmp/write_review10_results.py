from pathlib import Path
import csv,json,zipfile,sys,hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from run_q2_national import verify_latest
read=lambda p:json.loads(p.read_text(encoding='utf8'))
folder=ROOT/'outputs/q2/p2_lb_national'
manifest=read(folder/'run_manifest.json')
assert verify_latest(folder)==manifest
cal=read(folder/'calibration.json');coverage=read(folder/'experiment_coverage.json')
receipt=read(ROOT/'outputs/q2_review/p2_lb_national/verification.json')
tests=read(ROOT/'outputs/q2_review/p2_lb/tests.json')
assert receipt['passed'] and receipt['implementation_checks_passed'] and receipt['empirical_acceptance_passed']
binding=next(c for c in receipt['checks'] if c['name']=='latest_national_results_match_code_inputs_sources')
assert binding['passed'] and binding['detail']==manifest['run_id']
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in receipt['current_hashes'].items())
assert manifest['status']=='success_conditional_candidate' and manifest['fit_thresholds_passed']
parameters=cal['best']['parameters']
with zipfile.ZipFile(ROOT/'archive/q2_review9_policy_dispatch_failed.zip') as z:
    old=json.loads(z.read('outputs/q2/p2_lb_national/calibration.json'))
parts={r['metric']:r for r in cal['quality']['already_seen_evaluation']['components']}
previous={r['metric']:r for r in old['quality']['already_seen_evaluation']['components']}
lines=['# 问题二 review(9) 修复与V10实测结果','',
'2026-10-20；分支 `p2/lb`；PR #9 的 `dbb582c5fc887b800e857342665407d9d3a3bfdd` 为本轮代码起点，共同base仍为 `804ec15ee43874303986a7ad91b2cde05c65b124`。没有纳入PR #11的可选审批比例分配。','',
'**本轮代码检查、全部冻结经验误差门槛和完整独立复现均通过。结果仍是全国聚合条件研究候选，不能解释为所有单技术误差都合格、官方目标认证或团队批准。**','',
'方法依据及逐项修改见[V10结构修复](p2-lb-review10-structure.md)；统计桥和早期修复归因见[V8/V9过程记录](p2-lb-review9-response.md)。','',
'## 对应原review(9)的四项要求','',
'| 原问题 | 本轮状态与证据 |','|---|---|',
'| 最终代码没有有效全国交付收据 | 完整重跑训练、基准、107项条件试验及独立复现；收据绑定当前运行ID和代码、输入哈希，不能沿用旧成功记录。 |',
'| 政策目标统计代理不足以认定B5完整通过 | 已补官方分类依据、训练统计桥与回测及适用范围；数量仍含条件桥接，不能升级为官方口径的达标认证。团队是否接受该范围仍需明确决定。 |',
'| 油气历史校准缺少验收证据 | 已新增煤油气逐年物理份额、训练及冻结误差验收；本次全部通过，同口径排放留出缺失仍明确保留。 |',
'| 团队验收未完成 | 本轮为作者修复与独立进程自检；未代替另外两位成员对最终提交的正式批准，未合并或关闭Issue #7。 |','',
'## 修复与验证结果','',
'- 统计分类与折标依据保留官方原件；动态复合桥只用训练期拟合，独立2024锚与常数桥对照均保留。',
'- 煤油气消费分别进入物理燃料账、训练和验收；非发电需求从条件残差独立识别，避免代偿发电调度错误。',
'- 化石发电内部使用有物理约束的凸分段分配，真实支出与行为评分分账；缺燃料和价格冲击仍可改变结果，无硬发电下限。',
'- 修正初态平均在运容量分母、生物质交付能力增长代理；2014在建队列通过训练识别，2024初态独立重构；水核装机和八技术发电进入训练检查。',
'- 规划和实际供给包络一致；修复独立审查器变量覆盖，新增失败状态、来源用途、数值尺度和交付一致性检查。',
f"- 全量 **{tests['tests']}** 项测试通过，{tests['failures']}失败、{tests['errors']}错误、{tests['skipped']}跳过；20项工程验收通过。另一个智能体独立检查13项通过，默认调度4个夹具与V9逐字节一致。",
f"- **{cal['search_budget']}次**冻结候选调用全部成功；三轮有限分块交替搜索，只按2015—2021训练损失选择，不声称全联合穷举。条件试验 **{coverage['executed']}项**，成功{coverage['successful']}项。",
f"- 最终独立交付审查 **{len(receipt['checks'])}项全部通过**。独立进程更换哈希种子，重跑完整训练、S0和全部条件试验；**{len(manifest['outputs'])}份**科学产物逐字节一致。问题一18份科学产物、官方原件及原三项准入契约核对通过。",'',
'## 2022—2024已接触评估','',
'原验收门槛未放宽。份额误差为平均绝对误差MAE，单位百分点；其余为MAPE。V9是完整独立复现但未通过经验门槛的阶段结果，不是当前交付。','',
'| 指标 | V9 | V10 | 冻结门槛 |','|---|---:|---:|---:|']
specs=[('primary_energy_tce','能源总量','mape',10),('electricity_generation_mwh','总发电','mape',10),('total_capacity_mw','总装机','mape',20),('wind_capacity_mw','风电装机','mape',25),('solar_capacity_mw','光伏装机','mape',25),('peo_share','非化石份额','mae',3),('coal_share','煤份额','mae',2),('oil_share','油份额','mae',2),('gas_share','气份额','mae',1)]
for metric,label,key,gate in specs:
    unit='个百分点' if key=='mae' else '%'
    lines.append(f"| {label} | {previous[metric][key]*100:.4f}{unit} | {parts[metric][key]*100:.4f}{unit} | ≤{gate}{unit} |")
lines+=['',f"油、气份额MAPE分别为{parts['oil_share']['mape']:.2%}、{parts['gas_share']['mape']:.2%}，均低于原20%门槛。水、核装机MAPE分别为{parts['hydro_capacity_mw']['mape']:.2%}、{parts['nuclear_capacity_mw']['mape']:.2%}；两者是新增训练/诊断指标，不假称来自原七项验收。",'',
'## 参数与边界','',
'训练选出的参数：','', '```json',json.dumps(cal['best']['parameters'],ensure_ascii=False,indent=2),'```','',
f"水电建设能力系数本次选为{parameters['hydro_construction_response']:g}；水电初始队列倍率为{parameters['hydro_initial_pipeline_multiplier']:g}，核电初始队列倍率为{parameters['nuclear_initial_pipeline_multiplier']:g}。结果来自新增分技术约束下的联合选择；若建设能力系数为1，不能将拟合改善归因于降低了该系数。这些是训练识别参数，不是机组普查结果。",'',
'逐技术发电误差仍须单独公开，不能用总量与煤油气份额过关替代它们：','',
'| 技术 | 2022—2024发电MAPE |','|---|---:|']
for tech,label in [('coal','煤'),('gas','气'),('oil','油'),('biomass','生物质'),('hydro','水'),('nuclear','核'),('wind','风'),('solar','光')]:
    lines.append(f"| {label} | {parts[tech+'_generation_mwh']['mape']:.2%} |")
lines+=['',
'气、油、生物质发电量仍有较大偏差，不能据此宣称这些技术的利用率、盈利和投产机制已得到全国实证验证。当前聚合收入与项目重构假设没有逐省/机组数据支撑；已查到的地方电价不能直接冒充全国历年平均。代表日不验证全年可靠性，水电/抽蓄和非电清洁能源等边界仍由明确的条件口径处理。',
'',
'2022—2024被结构修订多次接触，保持“已接触评估”身份；2022—2024同口径BTR燃烧CO₂清单缺失，既不补零，也不称为通过独立排放验证。非化石数量采用训练拟合的复合统计桥；未来政策目标对比和过程排放/碳汇路径仍为条件推演，非官方达标或全温室气体碳中和认证。','',
'## 交付证据','',
f"- 正式运行ID（UTC）：`{manifest['run_id']}`。",
'- `outputs/q2/p2_lb_national/`：模型快照、冻结设计、训练记录、历史/未来路径、份额/技术残差、需求识别、统计桥、条件试验与报告。',
'- `outputs/q2_review/p2_lb_national/verification.json`：最终独立交付收据；`outputs/q2_review/p2_lb/verification.json`：工程验收收据。',
'- `archive/q2_review9_policy_dispatch_failed.zip`：完整V9失败阶段；`archive/q2_review10_identification_diagnostic.zip`：V10首轮575次诊断；更早阶段归档保持。',
'- 团队交叉批准仍应针对最终提交进行；本报告没有代替成员签字，也没有关闭Issue #7。','']
(ROOT/'docs/solutions/p2-lb-review9-results.md').write_text('\n'.join(lines),encoding='utf8')
print('Wrote final evidence-based results; checks',len(receipt['checks']))
