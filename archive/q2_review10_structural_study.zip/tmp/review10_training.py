"""Isolated structural training experiment; no evaluation selection."""
from pathlib import Path
import sys, math, json
from copy import deepcopy
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts'),str(ROOT/'tmp/review9_scope')]
import energy_model.q2_national as n
import run_q2_national as runner
from pwl_dispatch_fixed import operate
n.operate=operate
old_gen=n.NationalGenerator.__init__
def gen(self,model,name,capacity,cf,capex,om):
    if name in ('hydro','nuclear','wind','solar'):
        previous=n.get(model.data,model.initial_year-1,name+'_capacity_mw')
        cf=min(.9,model.initial_generation[name]/(8760*(previous+capacity)/2))
    old_gen(self,model,name,capacity,cf,capex,om)
n.NationalGenerator.__init__=gen
old_build=n.NationalModel.build_initial_cohorts
def build(self):
    old_build(self)
    if self.initial_year==2014:
        for p in self.projects:
            scale=self.theta.get(p['tech']+'_initial_pipeline_multiplier',1)
            for field in ('capacity_mw','cost','instalment','remaining'):
                p[field]*=scale
n.NationalModel.build_initial_cohorts=build
old_init=n.NationalModel.__init__
def init(self,*args,**kw):
    old_init(self,*args,**kw)
    self.supply_growth['biomass']=(n.get(self.data,2014,'biofuel_electricity_mwh')/n.get(self.data,2005,'biofuel_electricity_mwh'))**(1/9)-1
n.NationalModel.__init__=init
old_make=n.NationalModel.make_operation
def make(self):
    op=old_make(self)
    kappa=self.theta.get('dispatch_kappa',300)
    if kappa:
        op['fossil_allocation_score']=dict(kappa=kappa,plants={f:dict(reference_cf=self.generators[f].reference_cf,
            initial_marginal_cost=self.generators[f].om+self.suppliers[f].price/self.efficiency[f]) for f in n.FUELS})
    return op
n.NationalModel.make_operation=make

def prepare():
    data,design,_=runner.preflight()
    for f in n.FUELS:
        def residual(y):
            return data[y,'consumption_10ktce']*1e4*n.TCE_MWH*data[y,'consumption_'+f+'_pct']*.01-data[y,f+'_electricity_mwh']/dict(coal=.41,oil=.38,gas=.52)[f]
        x=[math.log(data[y,'real_gdp']/data[2014,'real_gdp']) for y in range(2015,2022)]
        z=[math.log(residual(y)/residual(2014))-(y-2014)*math.log(.99) for y in range(2015,2022)]
        key='activity_elasticity' if f=='coal' else f+'_activity_elasticity'
        design['calibration_search']['initial_parameters'][key]=sum(a*b for a,b in zip(x,z))/sum(a*a for a in x)
        del design['parameter_grid'][key]
    design['parameter_grid'].update(dispatch_kappa=[100,300,1000],hydro_initial_pipeline_multiplier=[.25,.5,1,1.5,2],nuclear_initial_pipeline_multiplier=[.5,1,1.5,2,2.5])
    design['calibration_search']['initial_parameters'].update(dispatch_kappa=300,hydro_initial_pipeline_multiplier=1,nuclear_initial_pipeline_multiplier=1)
    design['calibration_search']['blocks']=[['hydro_initial_pipeline_multiplier','nuclear_initial_pipeline_multiplier'],['expectation_rate','investment_response','renewable_mix_response','solar_construction_growth'],['dispatch_kappa','replacement_adoption']]
    design['search_budget']=1+design['calibration_search']['passes']*sum(math.prod(len(design['parameter_grid'][k]) for k in block) for block in design['calibration_search']['blocks'])
    # Preserve generation-family total weight, but resolve its internal mixture.
    for t in design['targets']:
        if t['metric']=='electricity_generation_mwh':t['weight']=.5
    for tech in n.TECHS:
        obs=('biofuel' if tech=='biomass' else tech)+'_electricity_mwh'
        scale=sum(data[y,obs] for y in range(2015,2022))/7*.2
        design['targets'].append(dict(metric=tech+'_generation_mwh',observation=obs,multiplier=1,scale_from_training_mean_fraction=.2,scale=scale,weight=.5/8))
    return data,design

if __name__=='__main__':
    data,design=prepare()
    folder=ROOT/'tmp/review10_training'
    folder.mkdir(exist_ok=True)
    runner.dump(folder/'frozen_design.json',design)
    result=runner.calibrate(data,design,folder)
    runner.dump(folder/'calibration.json',result)
    print(json.dumps(result['best']),flush=True)
