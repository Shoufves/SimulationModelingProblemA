"""Independent read-only integration probes; no scientific run or production edits."""
from pathlib import Path
from copy import deepcopy
import json,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/"src"),str(ROOT/"scripts")]
from run_q2_national import preflight
from energy_model.q2_identification import fit_nonpower,identified_parameters
from energy_model.q2_national import NationalModel,operate_national,FUELS,LEAD

data,design,_=preflight()
theta=dict(design["calibration_search"]["initial_parameters"])
checks={}
changed=deepcopy(data)
for key in changed:
    if key[0]>=2022:changed[key]*=17
checks["evaluation_data_never_changes_demand_fit"]=fit_nonpower(data,design)==fit_nonpower(changed,design)
original=NationalModel(data,design,theta,2014,detail=False).run(2016).paths
# Historical price-level conversion uses 2024 values as declared reconstruction;
# perturb physical inputs only to isolate unintended observed-path injection.
changed=deepcopy(data)
for key in changed:
    if key[0]>=2015 and ("capacity" in key[1] or "consumption" in key[1] or "electricity" in key[1]):
        changed[key]*=17
other=NationalModel(changed,design,theta,2014,detail=False).run(2016).paths
checks["postinitial_physical_observations_never_enter_state"]=original==other

changed_theta={**theta,"hydro_initial_pipeline_multiplier":2,"nuclear_initial_pipeline_multiplier":2.5}
historical=NationalModel(data,design,changed_theta,2014)
forecast=NationalModel(data,design,theta,2024)
forecast_changed=NationalModel(data,design,changed_theta,2024)
checks["2024_pipeline_ignores_2014_inferred_multiplier"]=forecast.projects==forecast_changed.projects
for tech in ("hydro","nuclear"):
    expected=historical.initial_additions[tech]*changed_theta[tech+"_initial_pipeline_multiplier"]
    checks[tech+"_2014_pipeline_matches_inferred_multiplier"]=all(abs(p["capacity_mw"]-expected)<1e-9
        for p in historical.projects if p["tech"]==tech)

# Cash payments for reconstructed in-flight projects reconcile with initial
# remaining commitments; future model decisions are independent extra projects.
initial={p["id"]:dict(p) for p in historical.projects}
initial_reserved=historical.construction_fund
historical.run(2021)
payments={pid:sum(r["resource_cost_cny"] for r in historical.finance if r.get("project")==pid and r["kind"]=="construction")
          for pid in initial}
checks["every_initial_commitment_paid_exactly_before_commissioning"]=all(
    abs(payments[pid]-p["remaining"])<=max(.01,p["remaining"]*1e-12) for pid,p in initial.items())
checks["initial_reserved_fund_equals_initial_remaining"]=abs(initial_reserved-sum(p["remaining"] for p in initial.values()))<.01
checks["all_year_cash_and_escrow_balances_close"]=all(
    abs(r["cash_balance_residual_cny"])<.1 and abs(r["construction_fund_residual_cny"])<.1
    for r in historical.paths)
checks["all_initial_projects_mature_once"]=all(
    sum(c["id"]==pid for c in historical.cohorts)==1 for pid in initial)

# The score anchor must be invariant to the real fuel-price sensitivity.
a=NationalModel(data,design,theta,2024)
b=NationalModel(data,design,theta,2024,variant={"fuel_price_multiplier":1.5})
a.drivers();a.mature();b.drivers();b.mature()
oa,ob=a.make_operation(),b.make_operation()
checks["actual_fuel_price_shock_preserved"]=all(ob["fuels"][f]["domestic_cost_per_mwh"]==1.5*oa["fuels"][f]["domestic_cost_per_mwh"] for f in FUELS)
checks["initial_score_cost_not_refit_to_price_shock"]=oa["fossil_allocation_score"]==ob["fossil_allocation_score"]
result=operate_national(oa)
checks["national_wrapper_restores_cost_score_identity"]=abs(
    result["actual_dispatch_cost"]+result["behavioral_score"]-result["dispatch_objective"])<.01
checks["national_wrapper_restores_reference_fossil_mwh"]=abs(
    result["reference_fossil_mwh"]-sum(r["output_mwh"] for r in result["generation"] if r["plant"] in FUELS))<1e-5
report=dict(passed=all(checks.values()),checks=checks,demand_parameters=identified_parameters(fit_nonpower(data,design)),
    limitation="No final empirical acceptance, national calibration or official certification tested")
(ROOT/"tmp/review9_scope/v10_integration_review.json").write_text(json.dumps(report,indent=2),encoding="utf8")
print(json.dumps(report))
assert report["passed"]
