from pathlib import Path
import sys,unittest,json
from copy import deepcopy
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/"tests"),str(ROOT/"src"),str(Path(__file__).parent)]
from pwl_dispatch_fixed import operate,Q2Error
from energy_model.q2_operations import operate as old_operate
from test_q2_operations import dispatch_case

def case():
    p=dispatch_case()
    p["demands"]["load"]["service_mwh"]=[10,10]
    p["plants"]={"coal":p["plants"]["coal"]}
    p["plants"]["gas"]=deepcopy(p["plants"]["coal"])
    p["plants"]["gas"]["input"]="gas"
    p["fuels"]["gas"]=deepcopy(p["fuels"]["coal"])
    p["fuels"]["gas"]["domestic_cost_per_mwh"]=3
    p["fuels"]["gas"]["import_cost_per_mwh"]=3
    p["fossil_allocation_score"]=dict(kappa=20,plants={
        "coal":dict(reference_cf=.25,initial_marginal_cost=1),
        "gas":dict(reference_cf=.25,initial_marginal_cost=3)})
    return p

def outputs(result):
    return {f:sum(r["output_mwh"] for r in result["generation"] if r["plant"]==f) for f in ("coal","gas")}

class Tests(unittest.TestCase):
    def test_optional_default_exactly_matches_old(self):
        p=case();p.pop("fossil_allocation_score")
        new=operate(p);old=old_operate(p)
        for k in old:self.assertEqual(new[k],old[k])

    def test_feasible_anchor_shares_and_cash_not_score(self):
        p=case();r=operate(p);g=outputs(r)
        self.assertAlmostEqual(g["coal"],10)
        self.assertAlmostEqual(g["gas"],10)
        self.assertAlmostEqual(r["resource_cost"],40)
        self.assertAlmostEqual(r["resource_cost"]+r["policy_signal_cost"],r["actual_dispatch_cost"])
        self.assertAlmostEqual(r["dispatch_objective"],r["actual_dispatch_cost"]+r["behavioral_score"])
        self.assertNotAlmostEqual(r["resource_cost"],r["dispatch_objective"])

    def test_zero_demand_never_forces_generation(self):
        p=case()
        for demand in p["demands"].values():demand["service_mwh"]=[0,0]
        r=operate(p)
        self.assertEqual(sum(outputs(r).values()),0)
        self.assertEqual(r["resource_cost"],0)

    def test_fuel_absence_allows_gas_zero(self):
        p=case();p["fuels"]["gas"]["domestic_mw"]=[0,0]
        r=operate(p)
        self.assertEqual(outputs(r)["gas"],0)
        self.assertAlmostEqual(outputs(r)["coal"],20)

    def test_price_shock_changes_choice_but_not_reference_cost(self):
        p=case();base=outputs(operate(p))
        p["fuels"]["gas"]["domestic_cost_per_mwh"]=30
        p["fuels"]["gas"]["import_cost_per_mwh"]=30
        r=operate(p);other=outputs(r)
        self.assertLess(other["gas"],base["gas"])
        self.assertGreater(other["coal"],base["coal"])
        self.assertEqual(p["fossil_allocation_score"]["plants"]["gas"]["initial_marginal_cost"],3)
        self.assertAlmostEqual(sum(other.values()),sum(base.values()))

    def test_clean_dispatch_not_displaced_even_before_policy(self):
        p=case()
        p["plants"]["wind"]=deepcopy(p["plants"]["coal"])
        p["plants"]["wind"].update(input=None,capacity_mw=5)
        old=deepcopy(p);old.pop("fossil_allocation_score")
        before=old_operate(old);after=operate(p)
        def wind(r):return sum(x["output_mwh"] for x in r["generation"] if x["plant"]=="wind")
        self.assertAlmostEqual(wind(before),wind(after))
        self.assertAlmostEqual(sum(outputs(after).values()),sum(outputs(before).values()))

    def test_lossy_storage_not_rewarded_by_negative_behavior_slopes(self):
        p=case()
        p["storage"].update(power_mw=20,energy_mwh=20,charge_efficiency=.8,discharge_efficiency=.8)
        r=operate(p)
        self.assertAlmostEqual(sum(outputs(r).values()),20)
        self.assertAlmostEqual(sum(x["charge_mwh"] for x in r["storage"]),0)
        self.assertAlmostEqual(sum(x["discharge_mwh"] for x in r["storage"]),0)

    def test_capacity_and_grid_limits_still_hold(self):
        p=case();p["plants"]["gas"]["capacity_mw"]=1
        r=operate(p);self.assertLessEqual(outputs(r)["gas"],2+1e-8)
        p=case();p["grid"]["power_mw"]=4
        r=operate(p)
        self.assertAlmostEqual(sum(x["served_service_mwh"] for x in r["demand"]),8)
        self.assertAlmostEqual(sum(outputs(r).values()),8)

    def test_repeat_cost_not_stock_scaling(self):
        a=case();b=deepcopy(a);b["annual_repeats"]=2
        r1=operate(a);r2=operate(b)
        self.assertEqual(outputs(r1),outputs(r2))
        self.assertAlmostEqual(r2["resource_cost"],2*r1["resource_cost"])
        self.assertAlmostEqual(r2["behavioral_score"],2*r1["behavioral_score"])

    def test_energy_scale_invariant(self):
        def scale(obj):
            if isinstance(obj,dict):
                return {k:([x*1000 for x in v] if isinstance(v,list) else v*1000)
                    if ((k.endswith(("_mwh","_mw")) and "_per_" not in k) or k=="ramp_mw_per_hour")
                    else scale(v) for k,v in obj.items()}
            return deepcopy(obj)
        a=case();b=scale(a);r1=operate(a);r2=operate(b)
        for f in ("coal","gas"):self.assertAlmostEqual(outputs(r2)[f],outputs(r1)[f]*1000)
        self.assertAlmostEqual(r2["resource_cost"],r1["resource_cost"]*1000)
        self.assertAlmostEqual(r2["behavioral_score"],r1["behavioral_score"]*1000)

    def test_invalid_scope_rejected(self):
        for mutate in (
            lambda p:p["fossil_allocation_score"].update(kappa=-1),
            lambda p:p["fossil_allocation_score"]["plants"]["gas"].update(reference_cf=0),
            lambda p:p["fossil_allocation_score"]["plants"].update(absent=dict(reference_cf=.2,initial_marginal_cost=3))):
            p=case();mutate(p)
            with self.assertRaises(Q2Error):operate(p)

if __name__=="__main__":unittest.main()
