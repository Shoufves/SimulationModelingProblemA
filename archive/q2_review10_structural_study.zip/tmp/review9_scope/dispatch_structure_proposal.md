# Read-only structure study, 2026-10-20

Production CODE was not modified. Both PWL experiments use only 2014 initial information and 2015–2021 training outcomes, with V9's old theta held fixed. They neither select nor inspect 2022–2024 generation for parameter choice.

## Update: preferred boundary-corrected implementation

Use `pwl_dispatch_fixed.py:operate`, not the earlier unfrozen score prototype, for further integration. The fixed-total version performs one extra LP:

1. Existing shortage stages and, when announced, nonfossil priority stage.
2. Original true-resource-plus-policy objective, yielding reference total selected fossil generation F*.
3. Freeze only Σ_i,t fossil_generation_it=F*, then minimise the real objective plus within-fossil PWL score. Do not freeze each fossil output or the first-stage resource cost.

Thus the allocation score cannot alter the pre-policy2015 fossil/nonfossil quantity decision or invent a gas floor. It can substitute gas/oil for coal inside the selected fossil quantity, incurring the corresponding **real** costs. This is an explicit sequential behavioural approximation; it retains the original single-node model's inability to identify regional CHP or peaking services.

Interface:

    op["fossil_allocation_score"] = {
        "kappa": 300,
        "plants": {
            fuel: {
                "reference_cf": generator.reference_cf,
                "initial_marginal_cost": generator.om + supplier.price/eta
            } for fuel in ("coal","oil","gas")
        }
    }

Disable by omitting the key, not kappa=0. κ must be positive. The module validates selected known fuelled electricity plants, reference_cf in(0,1], and finite nonnegative initial marginal cost. It returns `actual_dispatch_cost`, `behavioral_score` and `reference_fossil_mwh` in addition to existing fields. National numerical scaling must explicitly restore these three diagnostics; costs scale like energy, the reference total like MWh.

`test_pwl_dispatch_fixed.py` independently passed11 counterexamples: absent-key compatibility; feasible initial mixture; zero demand; absent gas supply; real-price response; unchanged clean dispatch before policy; no lossy cycle reward; hard gas capacity and grid limits; annual-repeat scaling; uniform energy scaling; invalid scope rejection. The test did not claim annual validation or pipeline calibration.

`pwl_fixed_training_probe.json` records four training-only probes. At κ=300 the coal/gas/oil training generation MAPE is9.77%/28.87%/35.70%, old total training loss1.21818 (old loss1.19509), max physical residual3.64e−9MWh, max cash residual0.00684CNY. The old theta is fixed, so there is no claim of a final fit. Gas/oil2021 outputs are149.25/31.84TWh; nonfossil outputs remain the same as the old run. Use these results in preference to the earlier c_ref experiments below.

`fit_nonpower_demand.py` is a reusable independent training-only tool. Its output is `nonpower_demand_training_fit.json`, including fitted rows, eta, assumptions and a successful >=2022 perturbation independence check. Training residual-proxy MAPE is coal1.61%, oil0.92%, gas4.68%; these are proxy fits, not separately observed final-energy verification.

## 1. Recommended minimal representation

Keep every existing fuel, electricity, storage, spending and cash constraint. Do not invent heat load, waste throughput, gas must-run power, ancillary revenue or a measured national market friction.

The linear national merit order wrongly interprets an aggregate heterogeneous fleet as perfectly interchangeable. Add an explicitly labelled **generalised decision score**, separate from actual resource cost and all financial settlements.

For conventional technology i in coal/gas/oil:

* B_i = initial annual generation /365 × current model capacity / initial capacity. Units: MWh per representative day. This is an initial allocation prior, not an obligation to generate.
* c_i0 = initial reference fuel purchase price / efficiency + real variable O&M, in real CNY/MWh. Account separately for any declared real policy signal and import premium. It is not an observed unit-level marginal cost.
* H_i(Q_i) = (c_ref − c_i0)Q_i + κ/(2B_i)(Q_i−B_i)^2, up to an irrelevant constant.
* Decide using C_true + annual_repeats × Σ H_i; settle using C_true only.

At a compatible unconstrained anchor, initial generalised marginal scores equal c_ref at Q_i=B_i. Capacity, fuel scarcity, demand and actual relative cost changes still matter. κ controls the extent of substitution; it is not a payment, subsidy or welfare loss measured from data. These are PMP-inspired reduced-form curves, not empirical proof of China's exact dispatch institution.

For a linear solver use segment volumes z_ik ≥0 with bounds B_i(r_{k+1}−r_k), and Σ_k z_ik = Σ_t generation_it. Add slope

    annual_repeats * [c_ref − c_i0 + κ((r_k+r_{k+1})/2−1)]

to the decision objective for segment k. Suggested fixed ratios:

    0,.25,.5,.75,.9,1,1.1,1.25,1.5,2,3,5,10

plus the exact physical maximum, clipping all larger ratios. Equal-width fine segments are an alternative. The prototype has no required minimum output and retains all physical limits. Do not apply this fossil allocation calibration to wind/solar, or claim it fixes deficient installed capacity or resource availability.

Important integration details:

1. Existing `LP.var(cost)` prohibits negative real costs. Create segments at zero real cost and use a separate unrestricted finite generalised-objective vector.
2. `resource_cost` must be explicitly Σ_j actual_cost_j*x_j minus the actual policy signal. Existing `result.fun-policy_cost` becomes wrong after introducing H.
3. Export actual resource objective, actual policy signal, behavioural score, total generalised objective and stage names separately. Real generator fuel bills and tariffs remain independent of H.
4. All costs and H receive the same `annual_repeats`; stock recurrences do not.
5. In 2016+ the prior fossil-displacement stage fixes total fossil output, so a common c_ref has no influence on the coal/gas/oil allocation. In 2015 it can change fossil/nonfossil ranking. A safe nonnegative-slope convention is c_ref=max_i(c_i0)+κ. Alternatively explicitly freeze the economically selected total fossil residual before the allocation stage. The latter is a different behavioural rule and must be declared, not silently introduced as the 2016 policy before publication.
6. With initial zero observed generation, do not invent B_i>0. Such technology requires a separate future-entry rule or a declared prior sensitivity.
7. Initial observed annual shares do not identify hourly dispatch; B_i is a whole-window allocation prior. The four-period chronology remains synthetic.

## 2. Fixed training-only probes

`pwl_dispatch_probe.py` dynamically extends the current operation code in memory; it never writes production modules. Four 2014→2021 runs per experiment, no formal calibration, old theta unchanged:

| κ | coal generation training MAPE | gas MAPE | oil MAPE | old training loss |
|---|---:|---:|---:|---:|
| off (original merit order) | 13.81% | 100% | 100% | 1.19509 |
| 100, common nonnegative slopes | 10.20% | 35.15% | 64.28% | 1.20441 |
| 300, common nonnegative slopes | 9.63% | 29.72% | 35.70% | 1.21491 |
| 1000, common nonnegative slopes | 9.56% | 29.72% | 28.61% | 1.21722 |

At κ=300, 2021 gas generation is 149.25 TWh versus 287.10 observed; oil 31.84 versus 57.06; coal 5756.32 versus 5333.80. Physical maximum residual ≤3.64e−9 MWh and cash residual ≤0.00684 CNY. No claim that these residual errors pass acceptance.

Gas output remains low because dispatch alone does not fix its capacity/investment path. Hydro/nuclear/wind/solar outputs are almost unchanged by the fossil mix score: their volume errors need capacity and utilisation decomposition. The old theta overcompensated for absent gas/oil conversion demand, so a slightly worse old total loss is not a reason to retain the corner solution.

Raw evidence: `pwl_dispatch_probe.json` (c_ref=initial coal cost), `pwl_dispatch_probe_safe.json` (nonnegative-slope convention). Both probe runs predate any new production adoption. At κ=0 the entire correction is disabled; merely setting curvature to zero while retaining the intercept is not the pure-cost counterfactual.

## 3. Separately identifying nonpower fuel demand

For each f, derive a **conditional residual proxy**

    R_fy = NBS_primary_fy * TCE_MWH − observed_generation_fy / eta_f

using the same declared conversion efficiencies as the physical model. It includes non-energy feedstock and other transformation/statistical differences. Do not call it observed final consumption. It is useful for identifying the nonpower scale independently of a wrong power dispatch.

Fit only 2015–2021 anchored at 2014:

    log(R_fy / R_f2014) = alpha_f * log(GDP_y/GDP_2014)
                         + (y−2014)*log(1−0.01)

The zero-intercept least-squares alpha values are coal −0.26303, oil 0.84077, gas 1.59497. Pretraining 2005→2014 estimates are coal 0.39459, oil 0.66533, gas 1.56219. Coal exhibits a genuine regime difference; extrapolating a negative alpha forever needs an explicit future schedule/sensitivity.

The current V9 values −0.75/1.1/2 differ appreciably, consistent with compensating for erroneous conversion consumption. This is not proof that the residual estimates are physical sector elasticities. Keep nonenergy shares and eta as declared assumptions and vary them.

Possible minimal frozen rule: derive these three alphas analytically from training, rather than adding three more arbitrary grids; use modest common deltas [−.2,0,.2] only if a clearly separate training target warrants it. Simulated nonpower residual should enter a declared training family, preventing a wrong power mix from winning via terminal compensation. Avoid double weighting the same primary total: residual and total/share targets are dependent.

## 4. Freeze and validation protocol

Freeze before the next evaluation: segment scheme, initial B rule, c_ref convention, κ in [100,300,1000], pure merit-order control, constant eta, independent residual-demand fit, technology capacity/utilisation parameters and all existing scientific thresholds.

Choose κ and any technology parameters using only a single declared 2015–2021 generation-family loss, such as equal technology weights on training-MAPE or initial/training-scaled errors. Report both absolute and relative errors so tiny oil generation cannot dominate silently. Do not choose a separate κ for each evaluation year. Keep the 2022–2024 identity "already seen".

Minimum mechanism counterexamples: exact initial mixture if feasible; no generation at zero demand; gas/oil can fall to zero if fuel absent or cost changes sufficiently; relative price shock shifts shares in the right direction; physical capacity/grid/ramp/tank constraints unchanged; resource/cash cost independent of H; annual unit scaling invariant; no lossy storage loop rewarded; absent/disabled H reproduces old outputs; new fossil score never enters actual revenues.

Also inspect training/evaluation for every technology's capacity and effective utilisation separately, no unexplained zero model generation with positive observations, all four primary shares, the bridge-only backtest, and full forecast sensitivities. If the changes do not pass all original and added thresholds, leave them failed and disclose the remaining mechanisms.

## 5. Original methodological and institutional sources

Downloaded complete original PDFs and official tariff pages are adjacent to this note. `dispatch_research_sources.json` records exact URLs and SHA256.

* Howitt (1995), *Positive Mathematical Programming*, AJAE77(2):329–342. Author's university PDF. Relevant discussion pp330–331: representative-data LP overspecialisation, heterogeneous activity quality and nonlinear calibration; pp332–335 formal calibration and cost/yield functions. The paper concerns agriculture: it supports the mathematics by analogy, not China's dispatch facts or κ.
* IEA (2019), *China Power System Transformation*. Relevant printed pp14–15 and pp33–36 discuss administrative fair dispatch; scenario results around pp147–150 compare merit order and fixed hours, and explicitly preserve gas allocation in the economic-dispatch scenario. This establishes that pure uniform merit order is not the only defensible historical model. It does not supply a national gas floor or a measured Chinese PWL curve.

## 6. Minimal tariff evidence and admissible use

* NDRC2014[3009], signed 2014-12-31, effective 2015-01-01: gas tariffs differ by plant role/commissioning date, CHP/peaking/distributed type, provincial setting and gas-price linkage. This directly supports distinguishing gas revenue from a universal coal representative tariff.
* Guangdong2020[284], effective2020-08-01: 9F+ at ≤3500h .605 CNY/kWh; 9E ≤4000h .630; 6F− ≤5000h .640; excess .463. Applies to the specified non-Australian-contract categories. This is a regional historical representative schedule, not a national 2024 average. An original2021 notice subsequently suspends the excess-hours discount from2021-06-01; therefore do not extend the old hours cap uncritically.
* Shanghai2024[38], effective2024-09-01: peaking energy .5746 plus capacity37.01CNY/kW/month; CHP first2500h .5988, next2500h .5184, beyond5000h .4155 plus capacity36.50; distributed .9372. It supports two-part remuneration and heterogeneity. Do not treat a 2024 policy as known to 2014 actors.
* NDRC2010[1579], effective2010-07-01: qualifying agriculture/forestry biomass .750CNY/kWh including tax, exceptions for tendered/prior higher-price projects, renewable surcharge funds difference above local coal tariff.
* NDRC2012[801]: waste-incineration .650 only for electricity corresponding to280kWh per tonne incoming municipal waste; remaining generation local coal tariff. No measured national waste throughput is available here, so do not manufacture its eligibility volume.
* NDRC2022 official reply clarifies .750 applies to eligible noncompetitive2021 subsidy projects, with competitive tariffs capped at .750; also acknowledges arrears. Thus the model's aggregate biofuel generation cannot all be certified .750 cash received.

Practical recommendation: choose one explicitly named representative gas tariff (e.g. Guangdong2020 9F .605, inflation-adjusted to the model's real-money base), paired with other official points as sensitivity. Scope it as a conditional representative province/technology, not observation of national revenue. Biomass can use a labelled conditional mixture with the .65/.75 policy points as a range, but its unknown eligible volumes, project composition, taxes and subsidy collection require an uncertainty parameter. Capacity payments require a new explicit payer transfer and eligibility scope if adopted; do not add them silently or count them as resource cost.

Changing tariff only changes real revenues/investment in this model; it must not be subtracted from the physical social resource objective as a fictitious fuel-cost reduction. Do not set tariffs solely high enough to guarantee positive NPV. The .605 gas reference yields a positive gross margin above the current approximately.528CNY/kWh variable reference, but that does not guarantee capex recovery, future utilisation or actual national profitability.
