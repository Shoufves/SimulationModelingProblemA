from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
import sys,json,hashlib
from copy import deepcopy
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/"src"),str(ROOT/"tests")]
from energy_model.q2_operations import operate
from test_q2_operations import dispatch_case
from test_q2 import small_operation
archive=ROOT/"archive/q2_review9_policy_dispatch_failed.zip"
with ZipFile(archive) as outer:
    with ZipFile(BytesIO(outer.read("outputs/q2/p2_lb_national/model_snapshot.zip"))) as inner:
        name=next(x for x in inner.namelist() if x.endswith("src/energy_model/q2_operations.py"))
        old_source=inner.read(name)
old={}
exec(compile(old_source,"<archived_v9_operations>","exec"),old)
cases=[small_operation(),dispatch_case(),dispatch_case(),dispatch_case()]
cases[2]["fossil_displacement_priority_plants"]=["coal"]
cases[3]["fossil_displacement_priority_plants"]=["coal"]
cases[3]["fuels"]["biomass"]["domestic_mw"]=[2,2]
checks=[]
for i,case in enumerate(cases):
    previous=json.dumps(old["operate"](deepcopy(case)),sort_keys=True,separators=(",",":"))
    current=json.dumps(operate(deepcopy(case)),sort_keys=True,separators=(",",":"))
    assert previous==current, i
    checks.append(dict(case=i,json_sha256=hashlib.sha256(current.encode()).hexdigest(),byte_identical=True))
report=dict(passed=True,cases=checks,archived_module_sha256=hashlib.sha256(old_source).hexdigest(),
    current_module_sha256=hashlib.sha256((ROOT/"src/energy_model/q2_operations.py").read_bytes()).hexdigest(),
    current_tests_sha256=hashlib.sha256((ROOT/"tests/test_q2_operations.py").read_bytes()).hexdigest())
(ROOT/"tmp/review9_scope/default_dispatch_compatibility.json").write_text(json.dumps(report,indent=2),encoding="utf8")
print(json.dumps(report))
