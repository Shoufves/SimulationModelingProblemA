# Review (9): independent statistical-scope research

Read-only research. No production files changed.

## Confirmed local official statement

`data/raw/lb/base/nbs/yearbook2025/sm09.txt`, section 4:

- National energy chapter covers the whole society.
- The energy balance electricity-to-standard-coal coefficient uses average electricity generation coal consumption.
- The conversion efficiency table alone uses physical-equivalent conversion, 0.1229 kgce/kWh.

These are distinct accounting coefficients. NEA electricity supply coal consumption is not automatically the NBS electricity generation coal consumption coefficient.

`data/raw/batch1_national/nea_renewable_2024.html`:

- 2024 conventional hydro capacity: 377 GW; pumped storage: 58.69 GW.
- Hydro generation is 1423.9 TWh, but the passage does not provide a matching conventional-only generation split.
- Biomass generation is 208.3 TWh.
- The page does not supply the full national non-electric nonfossil consumption balance.

Thus the present model's all-hydro and biomass electricity aggregate cannot be silently interpreted as a complete national primary nonfossil energy balance.

## Confirmed new official web evidence

Both pages were actually retrieved with PowerShell Invoke-WebRequest after restricted DNS failed; original HTML snapshots are beside this note.

1. NBS Energy Statistics Department response dated 2026-04-17, submitted 2026-04-14:
   `https://www.stats.gov.cn/hd/lyzx/zxgk/202605/t20260509_1963653.html`
   Snapshot `nbs_fossil_nonfossil_20260417.html`, SHA256:
   `C69981A88456264889DDDE4F106686CE62854BB8332459A763C87BC30A90BA11`.
   Its reply classifies coal, oil, and gas as fossil; primary electricity from hydro, nuclear, wind, solar and biomass energy as nonfossil. Together the classifications exhaust energy types. It explicitly requires avoiding double counting primary/secondary consumption after conversion.

2. NBS energy transition report, 2026-06-04:
   `https://www.stats.gov.cn/sj/sjjd/202606/t20260604_1963892.html`
   Snapshot `nbs_energy_transition_20260604.html`, SHA256:
   `9317CDF48FB0267BAA1B7DD41F13AA0D7E83FEB7F687310B5B656785E5767990`.
   Section 3(2) explicitly links the coal/oil/gas/nonfossil four-category structure to the PEO share rising from 16.0% in 2020 to 21.7% in 2025 and achievement of the nonfossil policy target.

The second source provides a direct published category correspondence. It does not validate a particular model's future quantities or coefficients.

## Defensible implementation options

Exact component accounting would require conventional primary generation, appropriate consumption/trade boundaries, biomass primary input and non-electric nonfossil consumption, with the proper published statistical conversion coefficients. These components are currently incomplete.

A practical empirical bridge can instead define an explicitly composite coefficient:

`c_eff(year) = published_nonfossil_consumption_tce(year) / covered_nonfossil_generation_MWh(year)`

This includes non-electric uses, biomass transformation, net trade, source coverage and statistical revision effects. It must not be named "average generation coal consumption". Its provenance is an empirical statistical bridge, not an official calculation formula.

Train any evolution rule on the training window only. Preserve a constant-anchor accounting baseline and evaluate both against held-out official consumption shares without changing the existing threshold. A 2024 re-anchoring is appropriate for conditional projections but cannot be used as evidence of independent validation in 2024.

A finite-floor exponential path or bounded trend can be a transparent scenario assumption. Neither future floor nor decay parameter is an official fact. Report the yearly coefficient, anchor, fitting window, baseline comparison, and sensitivity. Do not split an aggregate residual into invented non-electric observations.

This can support an official-category-aligned *conditional policy estimate*. It cannot support official certification of target achievement or claims that all national physical/non-electric data gaps have been closed. Policy comparisons must retain their accounting sensitivity and conditional status.

## Independent review checks for proposed code

- Historical training starts at its historical anchor; the forecast's 2024 anchor does not leak into training.
- Only training observations affect coefficient evolution or selection.
- Original structural and total-energy thresholds remain in place.
- Oil and gas targets are actually calibrated and gated, not just printed.
- Coefficient updates use the same units as numerator and denominator.
- Every bridge observation is source-reviewed under its actual new use.
- PEO and the estimated policy share are related through documented category evidence, not a renamed field alone.
- Biomass primary input and electricity are not counted twice.
- Storage output is not counted as new primary production.
- Future policy output says conditional and cannot be read as official certification.
