from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/"src"),str(ROOT/"scripts"),str(Path(__file__).parent)]
import energy_model.q2_national as n
from run_q2_national import preflight,load,loss,generation_diagnostics
from pwl_dispatch_fixed import operate
data,design,_=preflight()
theta=load(ROOT/"outputs/q2/p2_lb_national/calibration.json")["best"]["parameters"]
old_make=n.NationalModel.make_operation
old_operate=n.operate
records=[]
for kappa in (0,100,300,1000):
    if kappa:
        n.operate=operate
        def make(self):
            op=old_make(self)
            op["fossil_allocation_score"]=dict(kappa=kappa,plants={f:dict(
                reference_cf=self.generators[f].reference_cf,
                initial_marginal_cost=self.generators[f].om+self.suppliers[f].price/self.efficiency[f]) for f in n.FUELS})
            return op
        n.NationalModel.make_operation=make
    else:
        n.operate=old_operate
        n.NationalModel.make_operation=old_make
    m=n.NationalModel(data,design,theta,2014,detail=False).run(2021)
    diagnostics=generation_diagnostics(m.paths,data,design)
    value,_,_=loss(m.paths,data,design,design["training_years"],"probe")
    record=dict(kappa=kappa,existing_loss=value,max_lp_residual=max(r["max_residual"] for r in m.paths),
        max_cash_residual=max(abs(r["cash_balance_residual_cny"]) for r in m.paths),technology={})
    for tech in n.TECHS:
        rows=[r for r in diagnostics if r["technology"]==tech]
        record["technology"][tech]=dict(training_mape=sum(abs(r["relative_error"]) for r in rows)/len(rows),
            modeled2021_twh=rows[-1]["simulated_mwh"]/1e6,observed2021_twh=rows[-1]["observed_mwh"]/1e6)
    record["theta_unchanged"]=theta
    records.append(record)
    print(json.dumps(record),flush=True)
(ROOT/"tmp/review9_scope/pwl_fixed_training_probe.json").write_text(json.dumps(records,indent=2),encoding="utf8")
