"""Training-only conditional nonpower-fuel proxy fit; no production mutation."""
from pathlib import Path
import sys,math,json,csv
from copy import deepcopy
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/"src"),str(ROOT/"scripts")]
from run_q2_national import preflight
from energy_model.q2_national import TCE_MWH,FUELS
ETA=dict(coal=.41,oil=.38,gas=.52)

def fit(data,years=range(2015,2022),anchor=2014,intensity_decline=.01):
    outputs=[]
    for fuel in FUELS:
        def residual(y):
            primary=data[y,"consumption_10ktce"]*1e4*TCE_MWH*data[y,"consumption_"+fuel+"_pct"]*.01
            power=data[y,fuel+"_electricity_mwh"]/ETA[fuel]
            if primary<=power:raise ValueError("Nonpositive conditional nonpower proxy")
            return primary-power
        r0=residual(anchor)
        x=[math.log(data[y,"real_gdp"]/data[anchor,"real_gdp"]) for y in years]
        z=[math.log(residual(y)/r0)-(y-anchor)*math.log(1-intensity_decline) for y in years]
        alpha=sum(a*b for a,b in zip(x,z))/sum(a*a for a in x)
        rows=[]
        for year in years:
            predicted=r0*(data[year,"real_gdp"]/data[anchor,"real_gdp"])**alpha*(1-intensity_decline)**(year-anchor)
            rows.append(dict(year=year,observed_conditional_residual_mwh=residual(year),
                fitted_conditional_residual_mwh=predicted,relative_error=predicted/residual(year)-1))
        outputs.append(dict(fuel=fuel,alpha=alpha,anchor_year=anchor,fit_years=list(years),eta=ETA[fuel],
            nonenergy_included=True,observed_final_consumption=False,
            training_mape=sum(abs(r["relative_error"]) for r in rows)/len(rows),training=rows))
    return outputs

if __name__=="__main__":
    data,design,_=preflight()
    result=fit(data)
    altered=deepcopy(data)
    for key in altered:
        if key[0]>=2022:altered[key]*=17
    assert fit(altered)==result
    report=dict(status="training_fit_only_not_production_adoption",fits=result,
        equation="R=NBS_primary_fuel*TCE_MWH - observed_fuel_generation/assumed_eta",
        limitations=["Residual includes nonenergy/other transformation/statistical differences",
            "Same fixed assumed efficiencies as model, not observed heat balances",
            "Generation and primary total are dependent evidence; avoid double weighting",
            "Coal negative training relation is not a perpetual physical law"],
        evaluation_perturbation_has_no_effect=True)
    out=ROOT/"tmp/review9_scope/nonpower_demand_training_fit.json"
    out.write_text(json.dumps(report,indent=2),encoding="utf8")
    print(json.dumps({r["fuel"]:dict(alpha=r["alpha"],training_mape=r["training_mape"]) for r in result}))
