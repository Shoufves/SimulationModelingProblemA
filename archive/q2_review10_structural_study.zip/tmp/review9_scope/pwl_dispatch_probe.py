"""Read-only experiment: dynamically extend LP in memory, never production files."""
from pathlib import Path
import sys, json, csv, math
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/"src"),str(ROOT/"scripts")]
import energy_model.q2_national as n
from run_q2_national import preflight,load,loss,generation_diagnostics
import numpy as np

source=(ROOT/"src/energy_model/q2_operations.py").read_text(encoding="utf8")
extension = '''
    behavioral = []
    for name, spec in config.get("behavioral_dispatch", {}).items():
        capacity = plants[name]["capacity_mw"] * sum(hours)
        anchor = capacity * spec["reference_cf"]
        maximum = min(capacity, plants[name]["window_energy_budget_mwh"])
        ratios = sorted({0., maximum/anchor, *[r for r in (0.25,.5,.75,.9,1,1.1,1.25,1.5,2,3,5,10) if r*anchor<maximum]})
        terms={g[name,t]:-1 for t in range(n)}
        for k,(left,right) in enumerate(zip(ratios,ratios[1:])):
            j=lp.var("behavior/"+name+"/"+str(k),anchor*(right-left))
            terms[j]=1
            slope=spec["reference_cost"]-spec["own_initial_cost"]+spec["kappa"]*((left+right)/2-1)
            behavioral.append((j,slope*weight))
        lp.eq(terms,0,"behavior-segments/"+name)
'''
source=source.replace('    stages = []',extension+'\n    stages = []')
source=source.replace('    result, residual = lp.solve(lp.cost, solver)',
'''    generalized=np.array(lp.cost,dtype=float)
    for j,slope in behavioral: generalized[j]+=slope
    result, residual = lp.solve(generalized, solver)''')
source=source.replace('resource_cost=float(result.fun)-policy_cost',
    'resource_cost=float(sum(x[j]*v for j,v in enumerate(lp.cost)))-policy_cost')
namespace={}
exec(compile(source,"<temporary_pwl_dispatch>","exec"),namespace)
custom=namespace["operate"]
data,design,_=preflight()
theta=load(ROOT/"outputs/q2/p2_lb_national/calibration.json")["best"]["parameters"]
original_make=n.NationalModel.make_operation
original_operate=n.operate
records=[]
safe="--nonnegative-slope" in sys.argv
for kappa in (0,100,300,1000):
    if kappa:
        n.operate=custom
        def modified_make(self):
            op=original_make(self)
            costs={f:self.generators[f].om+self.suppliers[f].price/self.efficiency[f] for f in n.FUELS}
            common=max(costs.values())+kappa if safe else costs["coal"]
            op["behavioral_dispatch"]={f:dict(reference_cf=self.generators[f].reference_cf,
                reference_cost=common,own_initial_cost=costs[f],kappa=kappa) for f in n.FUELS}
            return op
        n.NationalModel.make_operation=modified_make
    else:
        n.operate=original_operate
        n.NationalModel.make_operation=original_make
    model=n.NationalModel(data,design,theta,2014,detail=False).run(2021)
    rows=generation_diagnostics(model.paths,data,design)
    score,parts,_=loss(model.paths,data,design,design["training_years"],"probe")
    result=dict(kappa=kappa,existing_training_loss=score,technology={})
    for tech in n.TECHS:
        cells=[r for r in rows if r["technology"]==tech]
        result["technology"][tech]=dict(mape=sum(abs(r["relative_error"]) for r in cells)/len(cells),
            model2021_mwh=cells[-1]["simulated_mwh"],observed2021_mwh=cells[-1]["observed_mwh"])
    result["max_lp_residual"]=max(r["max_residual"] for r in model.paths)
    result["max_cash_residual"]=max(abs(r["cash_balance_residual_cny"]) for r in model.paths)
    result["last_fuel_shares"]={f:model.paths[-1][f+"_share"] for f in n.FUELS}
    records.append(result)
    print(json.dumps(result),flush=True)
(ROOT/("tmp/review9_scope/pwl_dispatch_probe_safe.json" if safe else "tmp/review9_scope/pwl_dispatch_probe.json")).write_text(json.dumps(records,indent=2),encoding="utf8")

fits=[]
for fuel in n.FUELS:
    def residual(y):
        primary=data[y,"consumption_10ktce"]*1e4*n.TCE_MWH*data[y,"consumption_"+fuel+"_pct"]*.01
        return primary-data[y,fuel+"_electricity_mwh"]/dict(coal=.41,oil=.38,gas=.52)[fuel]
    for anchor,years in ((2005,range(2006,2015)),(2014,range(2015,2022))):
        x=[math.log(data[y,"real_gdp"]/data[anchor,"real_gdp"]) for y in years]
        z=[math.log(residual(y)/residual(anchor))-(y-anchor)*math.log(.99) for y in years]
        alpha=sum(a*b for a,b in zip(x,z))/sum(a*a for a in x)
        fits.append(dict(fuel=fuel,anchor=anchor,years=list(years),alpha=alpha,
            residual_is_final_energy_observation=False,nonenergy_included=True))
(ROOT/"tmp/review9_scope/nonpower_fuel_elasticity_probe.json").write_text(json.dumps(fits,indent=2),encoding="utf8")
print(json.dumps(fits))
probe=n.NationalModel(data,design,theta,2014,detail=False)
probe.drivers();probe.mature()
op=probe.make_operation()
print("SPECS",json.dumps(op.get("behavioral_dispatch")))
result=n.operate_national(op)
print("ONE_YEAR_OUTPUT",json.dumps(result["generation"]))
print("STAGES",json.dumps(result["stages"]))
