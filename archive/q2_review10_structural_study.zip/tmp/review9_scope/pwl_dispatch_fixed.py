"""Experimental fixed-total fossil allocation, implemented only in memory.

No production module is changed. This deliberately reuses all existing physical
rows, real costs, shortages and optional nonfossil policy priority.
"""
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"src"))
source=(ROOT/"src/energy_model/q2_operations.py").read_text(encoding="utf8")

extension = '''
    behavioral = []
    allocation_plants = []
    allocation = config.get("fossil_allocation_score")
    if allocation is not None:
        if type(allocation) is not dict or set(allocation)!={"kappa", "plants"}:
            raise Q2Error("invalid_input", "Allocation needs kappa and plants")
        kappa = number(allocation["kappa"], "allocation curvature", 1e-9)
        specs = allocation["plants"]
        if type(specs) is not dict or len(specs)<2:
            raise Q2Error("invalid_input", "Allocation needs at least two plants")
        for name in sorted(specs):
            spec = specs[name]
            if name not in plants or plants[name]["input"] not in fuels or plants[name]["output"]!="electricity":
                raise Q2Error("invalid_input", "Allocation requires fuelled electricity")
            if type(spec) is not dict or set(spec)!={"reference_cf", "initial_marginal_cost"}:
                raise Q2Error("invalid_input", "Invalid allocation plant fields")
            cf = number(spec["reference_cf"], "allocation reference CF", 1e-9, 1)
            initial_cost = number(spec["initial_marginal_cost"], "initial marginal cost")
            capacity = plants[name]["capacity_mw"] * sum(hours)
            anchor = capacity * cf
            maximum = min(sum(plants[name]["capacity_mw"]*plants[name]["availability"][t]*hours[t] for t in range(n)),
                          plants[name]["window_energy_budget_mwh"])
            allocation_plants.append(name)
            terms={g[name,t]:-1 for t in range(n)}
            if anchor>0 and maximum>0:
                ratios = sorted({0., maximum/anchor, *[r for r in (0.25,.5,.75,.9,1,1.1,1.25,1.5,2,3,5,10) if r*anchor<maximum]})
                for k,(left,right) in enumerate(zip(ratios,ratios[1:])):
                    j=lp.var("behavior/"+name+"/"+str(k),anchor*(right-left))
                    terms[j]=1
                    slope=-initial_cost+kappa*((left+right)/2-1)
                    behavioral.append((j,slope*weight))
            lp.eq(terms,0,"behavior-segments/"+name)
'''

replacement = '''
    reference_fossil = None
    if allocation_plants:
        baseline, baseline_residual = lp.solve(lp.cost, solver)
        fossil_indices = [g[name,t] for name in allocation_plants for t in range(n)]
        reference_fossil = float(sum(baseline.x[j] for j in fossil_indices))
        lp.eq({j:1 for j in fossil_indices}, reference_fossil, "fixed-reference-fossil-total")
        stages.append({"stage":"reference-resource-cost", "objective":float(baseline.fun),
                       "status":int(baseline.status), "max_residual":baseline_residual})
    generalized=np.array(lp.cost,dtype=float)
    for j,slope in behavioral: generalized[j]+=slope
    result, residual = lp.solve(generalized, solver)
'''
assert source.count("    stages = []")==1
source=source.replace("    stages = []",extension+"\n    stages = []")
assert source.count("    result, residual = lp.solve(lp.cost, solver)")==1
source=source.replace("    result, residual = lp.solve(lp.cost, solver)",replacement)
source=source.replace('"stage": "resource-cost", "objective": float(result.fun)',
    '"stage": "fossil-allocation-score" if allocation_plants else "resource-cost", "objective": float(result.fun)')
source=source.replace("resource_cost=float(result.fun)-policy_cost",
    "resource_cost=float(sum(x[j]*v for j,v in enumerate(lp.cost)))-policy_cost")
source=source.replace('dispatch_objective=float(result.fun), policy_signal_cost=policy_cost,',
    '''dispatch_objective=float(result.fun), policy_signal_cost=policy_cost,
                actual_dispatch_cost=float(sum(x[j]*v for j,v in enumerate(lp.cost))),
                behavioral_score=float(sum(x[j]*v for j,v in behavioral)),
                reference_fossil_mwh=reference_fossil,''')
namespace={}
exec(compile(source,"<temporary_fixed_fossil_allocation>","exec"),namespace)
operate=namespace["operate"]
Q2Error=namespace["Q2Error"]

if __name__=="__main__":
    print("Import this module for isolated experiments; no production files changed.")
