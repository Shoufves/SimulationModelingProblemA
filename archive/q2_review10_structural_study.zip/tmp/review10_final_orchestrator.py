from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).resolve().parents[1]
steps=[('national',["run.py","q2","--config","workflow/q2_inputs.json","--output-dir","outputs/q2/p2_lb_national"]),
       ('independent',["scripts/review_q2_national_delivery.py"])]
for name,args in steps:
    print('Starting final '+name,flush=True)
    with (ROOT/('tmp/review10_final_'+name+'.log')).open('w',encoding='utf8') as f:
        result=subprocess.run([sys.executable,'-B','-X','utf8',*args],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
    print(name+' exit '+str(result.returncode),flush=True)
    if result.returncode:sys.exit(result.returncode)
report=json.loads((ROOT/'outputs/q2_review/p2_lb_national/verification.json').read_text(encoding='utf8'))
assert report['passed']
print('Complete: final independent delivery verification passed',flush=True)
