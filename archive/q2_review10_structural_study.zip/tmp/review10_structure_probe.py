from pathlib import Path
import sys, json, math
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts')]
import energy_model.q2_national as n
from run_q2_national import preflight,load,loss,generation_diagnostics
data,design,_=preflight()
theta=load(ROOT/'outputs/q2/p2_lb_national/calibration.json')['best']['parameters']
original_init=n.NationalModel.__init__
mode=sys.argv[1] if len(sys.argv)>1 else 'average'
def init(self,*args,**kwargs):
    original_init(self,*args,**kwargs)
    if mode in ('average','average_supply'):
        for t in ('hydro','nuclear','wind','solar'):
            previous=n.get(self.data,self.initial_year-1,t+'_capacity_mw')
            average=(previous+self.initial_capacities[t])/2
            self.generators[t].reference_cf=min(.9,self.initial_generation[t]/(8760*average))
    if mode=='average_supply':
        self.supply_growth['biomass']=(n.get(self.data,2014,'biofuel_electricity_mwh')/n.get(self.data,2005,'biofuel_electricity_mwh'))**(1/9)-1
n.NationalModel.__init__=init
fits={}
for f in n.FUELS:
    def residual(y):
        primary=data[y,'consumption_10ktce']*1e4*n.TCE_MWH*data[y,'consumption_'+f+'_pct']*.01
        return primary-data[y,f+'_electricity_mwh']/dict(coal=.41,oil=.38,gas=.52)[f]
    x=[math.log(data[y,'real_gdp']/data[2014,'real_gdp']) for y in range(2015,2022)]
    z=[math.log(residual(y)/residual(2014))-(y-2014)*math.log(.99) for y in range(2015,2022)]
    fits[f]=sum(a*b for a,b in zip(x,z))/sum(a*a for a in x)
results=[]
for kind in ('old_theta','nonpower_fit'):
    params=dict(theta)
    if kind=='nonpower_fit':
        params.update(activity_elasticity=fits['coal'],oil_activity_elasticity=fits['oil'],gas_activity_elasticity=fits['gas'])
    m=n.NationalModel(data,design,params,2014,detail=False).run(2021)
    score,parts,_=loss(m.paths,data,design,design['training_years'],'probe')
    out=dict(mode=mode,parameters=kind,training_loss=score,components=parts,generation=generation_diagnostics(m.paths,data,design),last=m.paths[-1])
    results.append(out)
    print(json.dumps(dict(mode=mode,parameters=kind,training_loss=score,last=m.paths[-1])),flush=True)
(ROOT/('tmp/review10_'+mode+'.json')).write_text(json.dumps(results,indent=2),encoding='utf8')
