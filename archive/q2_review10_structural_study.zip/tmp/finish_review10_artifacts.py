"""Keep verified repair evidence and archive duplicate task-owned attempts."""
from pathlib import Path
import hashlib,json,subprocess,zipfile,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from run_q2_national import verify_latest
review=ROOT/'outputs/q2_review/p2_lb_national'
receipt=json.loads((review/'verification.json').read_text(encoding='utf8'))
assert receipt['passed'] and receipt['implementation_checks_passed'] and receipt['empirical_acceptance_passed']
manifest=verify_latest(ROOT/'outputs/q2/p2_lb_national')
binding=next(c for c in receipt['checks'] if c['name']=='latest_national_results_match_code_inputs_sources')
assert binding['passed'] and binding['detail']==manifest['run_id']
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in receipt['current_hashes'].items())
for source,name in [('tmp/review10_final_national.log','author_run.log'),
                    ('tmp/review10_engineering.log','author_engineering.log'),
                    ('tmp/review10_final_independent.log','author_independent.log'),
                    ('tmp/review9_scope/v10_integration_review.json','independent_mechanism_checks.json'),
                    ('tmp/review9_scope/default_dispatch_compatibility.json','default_dispatch_compatibility.json'),
                    ('outputs/validation/workspace_audit.json','workspace_audit_final.json')]:
    (review/name).write_bytes((ROOT/source).read_bytes())

def package(destination,paths,reason):
    assert not destination.exists(),destination
    index={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
        for p in paths:z.write(p,p.relative_to(ROOT).as_posix())
        z.writestr('ARCHIVE_MANIFEST.json',json.dumps(dict(reason=reason,sha256=index),indent=2))
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None
        assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in index.items())
    return index

study=[p for p in (ROOT/'tmp/review9_scope').iterdir() if p.is_file() and p.suffix in {'.py','.json','.md','.pdf','.html','.txt'}]
study.extend(p for p in (ROOT/'tmp').glob('review10*.py') if p.is_file())
study.extend(ROOT/p for p in ('tmp/write_review10_results.py','tmp/finish_review10_artifacts.py'))
study.extend(p for p in (ROOT/'tmp/review10_training').glob('*') if p.is_file())
package(ROOT/'archive/q2_review10_structural_study.zip',study,
        'Exploratory study, not production acceptance. Early dynamic probes ran against the archived V9 snapshot; do not replay them over modified production and claim the same result. Unadmitted regional tariffs remain reference-only research, not national observations.')
raw=subprocess.run(['git','ls-files','--others','--exclude-standard','-z','outputs'],cwd=ROOT,capture_output=True,check=True).stdout
paths=[]
for name in raw.decode('utf8').split('\0'):
    if not name:continue
    p=(ROOT/name).resolve()
    if any(part.endswith('.attempts') for part in Path(name).parts) or name.startswith('outputs/q2/p2_lb_v10_training/') or name=='outputs/q2/p2_lb_v10_training.latest-attempt.json':
        assert p.is_relative_to(ROOT/'outputs/q2') and p.is_file(),p
        paths.append(p)
index=package(ROOT/'archive/q2_review10_preserved_attempts.zip',paths,
    'Only untracked attempts generated from the initially clean working tree during review9/10 repair. All bytes and hashes preserved before removing duplicate loose copies; tracked historical runs remain in place.')
# Exact verified paths only, no recursive shell deletion or tracked-file removal.
for p in paths:
    assert hashlib.sha256(p.read_bytes()).hexdigest()==index[p.relative_to(ROOT).as_posix()]
    p.unlink()
dirs=set()
for p in paths:
    cur=p.parent
    while cur!=ROOT/'outputs/q2':
        assert cur.is_relative_to(ROOT/'outputs/q2')
        dirs.add(cur);cur=cur.parent
for p in sorted(dirs,key=lambda p:len(p.parts),reverse=True):
    try:p.rmdir()
    except OSError:pass
# Current evidence remains under Q2 review; avoid unrelated global-output churn.
for rel in ('outputs/validation/tests.json','outputs/validation/workspace_audit.json'):
    value=subprocess.run(['git','show','HEAD:'+rel],cwd=ROOT,capture_output=True,check=True).stdout
    (ROOT/rel).write_bytes(value)
print(json.dumps(dict(archived_attempt_files=len(paths),study_files=len(study))))
