"""Independent checks from exported ledgers, plus optional fresh full reproduction.

This audit does not call the model's accounting or screening helpers to validate
their own outputs. It cannot confer team approval or empirical validity.
"""
import argparse
from collections import defaultdict
from datetime import datetime, timezone
import csv
import gzip
import hashlib
import json
from math import fsum,isclose,sqrt
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"scripts"))
from run_q3 import verify_latest


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding="utf-8-sig"))
def unpack(p):return json.loads(gzip.decompress(Path(p).read_bytes()))
def csv_read(p):
    with Path(p).open(encoding="utf-8-sig",newline="") as f:return list(csv.DictReader(f))
def save(p,value):Path(p).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8")
def close(a,b,label,absolute=.001,relative=1e-10):
    if not isclose(a,b,abs_tol=absolute,rel_tol=relative):raise ValueError(f"{label}: {a} != {b}")
def service(r):return r["sector"]+("/"+r["carrier"] if r["sector"]=="nonenergy_feedstock" else "")


def verify_flows(rows,period_hours,efficiency,grid_efficiency,opening=None):
    """Fuel/stock/SOC/electricity/service/combustion identities, original units."""
    grouped=defaultdict(list)
    for r in rows:grouped[int(r["period"])].append(r)
    fuels=sorted({r["fuel"] for r in rows if r["kind"]=="fuel"})
    previous = ({f:[r for r in rows if r["kind"]=="fuel" and r["fuel"]==f][-1]["closing_mwh"] for f in fuels}
                if opening is None else {f:opening["fuels"][f]["initial_mwh"] for f in fuels})
    previous_soc=None if opening is None else opening["storage"]["initial_mwh"]
    ef=dict(coal=.34056,oil=.26388,gas=.20196,biomass=0.)
    for i,part in sorted(grouped.items()):
        battery=next(r for r in part if r["kind"]=="storage")
        if previous_soc is not None:close(battery["opening_mwh"],previous_soc,"SOC continuity")
        close(battery["closing_mwh"],battery["opening_mwh"]+battery["charge_mwh"]*efficiency-battery["discharge_mwh"]/efficiency,"SOC state")
        previous_soc=battery["closing_mwh"]
        electric=fsum(r["output_mwh"] for r in part if r["kind"]=="generation" and r["output"]=="electricity")
        electric+=battery["discharge_mwh"]-battery["charge_mwh"]
        electric-=fsum(r["input_mwh"]/grid_efficiency for r in part if r["kind"]=="demand" and r["carrier"]=="electricity")
        close(electric,0,"electric conservation")
        for r in part:
            if r["kind"]=="fuel":
                fuel=r["fuel"]
                close(r["closing_mwh"],previous[fuel]+r["fill_mwh"]-r["withdrawal_mwh"],"fuel stock")
                close(r["domestic_mwh"]+r["import_mwh"]+r["withdrawal_mwh"]-r["fill_mwh"],r["direct_mwh"]+r["conversion_mwh"],"fuel flow")
                material=fsum(d["input_mwh"] for d in part if d["kind"]=="demand" and d["sector"]=="nonenergy_feedstock" and d["carrier"]==fuel)
                close(r["combustion_co2_t"],(r["direct_mwh"]+r["conversion_mwh"]-material)*ef[fuel],"combustion")
                previous[fuel]=r["closing_mwh"]
            if r["kind"]=="demand":close(r["served_service_mwh"]+r["unmet_service_mwh"],r["requested_service_mwh"],"service conservation")
    if opening is not None:
        for f in fuels:close(previous[f],opening["fuels"][f]["initial_mwh"],"restored fuel boundary")
        close(previous_soc,opening["storage"]["initial_mwh"],"restored SOC boundary")
    return len(grouped)


def audit_case(evidence,config,design):
    if evidence["outcome"]["status"]!="completed":return dict(status="failed_record_preserved")
    paths=evidence["paths"]
    if [p["year"] for p in paths]!=list(range(2025,2061)):raise ValueError("Incomplete annual horizon")
    by_year=defaultdict(list)
    for r in evidence["operations"]:by_year[r["year"]].append(r)
    r=design["assumptions"]["discount_rate"]
    efficiency=sqrt(design["assumptions"]["storage_roundtrip_efficiency"])
    total_emissions,total_cost=0.,0.
    for p in paths:
        year=p["year"]
        rows=by_year[year]
        periods=verify_flows(rows,[6]*4,efficiency,design["assumptions"]["grid_efficiency"])
        if periods!=4:raise ValueError("Wrong annual period count")
        emission=fsum(z["combustion_co2_t"] for z in rows if z["kind"]=="fuel")*365
        close(emission,p["combustion_co2_t"],"annual emission",absolute=.01)
        finance=[z for z in evidence["finance"] if z["year"]==year]
        public=[z for z in evidence["public_ledger"] if z["year"]==year]
        cost=fsum(z.get("resource_cost_cny",0) for z in finance)+fsum(z["resource_cost_cny"] for z in public)
        close(cost,p["resource_cost_cny"],"resource costs (no transfer double count)",absolute=.1)
        appropriation=fsum(z["appropriation_cny"] for z in public)
        close(appropriation,p["public_appropriation_cny"],"public commitment",absolute=.01)
        if appropriation>p["public_budget_cny"]+.01:raise ValueError("Public ceiling exceeded")
        close(fsum(z["public_payment_cny"]+z["recipient_receipt_cny"] for z in public),0,"public counterpart",absolute=.01)
        close(fsum(z.get("ets_transfer_cny",0) for z in finance),0,"ETS counterpart",absolute=.01)
        for key in ("infrastructure_fund_residual_cny","construction_fund_residual_cny","public_escrow_residual_cny"):
            close(p[key],0,key,absolute=.01)
        sectors=defaultdict(lambda:[0.,0.])
        for d in rows:
            if d["kind"]=="demand":
                sectors[service(d)][0]+=d["requested_service_mwh"]*365
                sectors[service(d)][1]+=d["unmet_service_mwh"]*365
        for metric in [z for z in evidence["annual_services"] if z["year"]==year]:
            requested,unmet=sectors[metric["sector"]]
            close(metric["requested_service_mwh"],requested,"annual requested")
            close(metric["unmet_service_mwh"],unmet,"annual unmet")
            close(metric["unmet_fraction"],unmet/requested if requested else 0.,"annual shortage ratio",absolute=1e-10)
        total_emissions+=emission
        total_cost+=cost/(1+r)**(year-2024)
    terminal=evidence["terminal_accounts"]
    close(terminal["cumulative_combustion_co2_t"],total_emissions,"cumulative emission",absolute=.01)
    close(terminal["discounted_resource_cost_cny"],total_cost,"discounted cost",absolute=.1)
    parts=["terminal_generation_value_cny","terminal_device_value_cny","terminal_grid_value_cny","terminal_storage_value_cny","terminal_gas_release_value_cny","terminal_paid_construction_value_cny"]
    close(fsum(terminal[k] for k in parts),terminal["terminal_asset_value_cny"],"terminal components",absolute=.1)
    close(total_cost-terminal["terminal_asset_value_cny"]/(1+r)**36,terminal["net_resource_cost_cny"],"net asset-adjusted cost",absolute=.1)
    for c in evidence["terminal_cohorts"]:
        if c["status"]=="active" and c.get("scheduled_exit_year",c["exit_year"])<=2060:
            raise ValueError("Deferred retirement crossed terminal deadline")
        if c["status"]=="active" and c["exit_year"]<=2060:raise ValueError("Technical life exceeded")
    for p in evidence["policy_projects"]:
        if p["online"]<=p["decision"] or p["exit"]<=p["online"]:raise ValueError("Instant or invalid project lifetime")
        payments=fsum(z["resource_cost_cny"] for z in evidence["public_ledger"] if z["project"]==p["id"] and z["kind"]=="public_construction")
        close(payments+p["remaining"],p["cost"],"public project funded cost",absolute=.01)
        if p["online"]<=2060 and p["remaining"]>.01:raise ValueError("Unpaid commissioned policy asset")
        early=[z for z in evidence["public_ledger"] if z["project"]==p["id"] and z["kind"]=="public_construction" and z["year"]>=p["online"]]
        if early:raise ValueError("Construction paid after commissioning")
    return dict(status="passed",years=len(paths),operations=len(evidence["operations"]),projects=len(evidence["projects"])+len(evidence["policy_projects"]))


def audit_events(folder,config,cases):
    metrics={(r["id"],r["event"],int(r["year"]),r["scenario"],r["sector"]):r for r in csv_read(folder/"transition_event_metrics.csv")}
    checked=0
    for path in sorted((folder/"events").glob("*.json.gz")):
        batch=unpack(path)
        if isinstance(batch,dict):raise ValueError("Failed event file: "+path.name)
        caseid=path.name.rsplit("-",1)[0]
        grouped=defaultdict(list)
        for event in batch:grouped[(event["event"],event["year"])].append(event)
        for (_,year),events in grouped.items():
            snapshot=cases[caseid]["snapshots"][str(year)]
            service_signature=None
            for event in events:
                rows=[dict(kind=kind,**r) for kind in ("fuel","storage","generation","demand") for r in event["result"][kind]]
                op=event["operation"]
                verify_flows(rows,[p["hours"] for p in op["periods"]],op["storage"]["charge_efficiency"],op["grid"]["efficiency"],snapshot)
                signature=[(r["period"],r["device"],r["requested_service_mwh"]) for r in event["result"]["demand"]]
                if service_signature is not None and signature!=service_signature:raise ValueError("Paired service requests changed")
                service_signature=signature
                requested,unmet=defaultdict(float),defaultdict(float)
                for row in event["result"]["demand"]:
                    requested[service(row)]+=row["requested_service_mwh"]
                    unmet[service(row)]+=row["unmet_service_mwh"]
                for sector,total in requested.items():
                    m=metrics[(caseid,event["event"],year,event["scenario"],sector)]
                    close(float(m["requested_service_mwh"]),total,"event requested")
                    close(float(m["unmet_service_mwh"]),unmet[sector],"event unmet")
                    close(float(m["unmet_fraction"]) if m["unmet_fraction"] else 0,unmet[sector]/total if total else 0,"event shortage fraction",absolute=1e-10)
                checked+=1
    return dict(event_cases=checked,per_service_rows=len(metrics))


def independently_screen(rows,policy):
    baseline=next(r for r in rows if r["policy_id"]=="none")
    feasible=[]
    for row in rows:
        if row["status"]!="completed":continue
        if float(row["cumulative_combustion_co2_t"])>float(baseline["cumulative_combustion_co2_t"])*policy["carbon_limit_ratio"]+1e-5:continue
        if float(row["discounted_resource_cost_cny"])>float(baseline["discounted_resource_cost_cny"])*policy["gross_cost_limit_ratio"]+.01:continue
        if max(float(row["worst_selection_service_fraction"]),float(row["worst_annual_service_fraction"]))>policy["service_limit"]+1e-10:continue
        feasible.append(row["policy_id"])
    return sorted(feasible)


def compare_files(left,right):
    compared=[]
    for path in sorted(left.glob("*.csv")):
        if path.name=="gaps_and_conflicts.csv":continue
        a,b=csv_read(path),csv_read(right/path.name)
        if len(a)!=len(b):raise ValueError("Reproduction row count: "+path.name)
        for x,y in zip(a,b):
            if set(x)!=set(y):raise ValueError("Reproduction columns: "+path.name)
            for key,value in x.items():
                if value==y[key]:continue
                try:
                    v,w=float(value),float(y[key])
                except ValueError:raise ValueError("Reproduction text: "+path.name+"/"+key)
                close(v,w,"reproduction "+path.name+"/"+key,absolute=.01 if "cny" in key else 1e-6,relative=1e-10)
        compared.append(dict(file=path.name,rows=len(a),bitwise_equal=sha(path)==sha(right/path.name)))
    # All detailed action/cash/stock records, not just summary rows.
    for sub in ("cases","events","plans","sensitivity_locks"):
        files=sorted((left/sub).glob("*"))
        for p in files:
            if sha(p)!=sha(right/sub/p.name):raise ValueError("Detailed reproduction differs: "+sub+"/"+p.name)
        compared.append(dict(directory=sub,files=len(files),bitwise_equal=True))
    if sha(left/"selection_lock.json")!=sha(right/"selection_lock.json"):raise ValueError("Selection lock differs")
    return compared


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir",default="outputs/q3/p3_mmj_v3")
    parser.add_argument("--evidence",default="outputs/validation/p3_mmj/complete_review_round1.json")
    parser.add_argument("--reproduction-root",type=Path)
    args=parser.parse_args()
    source=(ROOT/args.output_dir).resolve();target=(ROOT/args.evidence).resolve()
    record=dict(status="running",passed=False,team_approved=False,checked_at_utc=datetime.now(timezone.utc).isoformat(),
                auditor_sha256=sha(__file__),checks=[])
    def check(name,value):
        record["checks"].append(dict(name=name,passed=True,detail=value));save(target,record)
    save(target,record)
    try:
        manifest=verify_latest(source)
        if manifest["status"]!="conditional_experiments_completed":raise ValueError("Full experiment receipt missing")
        record["run_id"]=manifest["run_id"];record["code_hashes"]=manifest["code_hashes"]
        check("current_complete_experiment_receipt",manifest["run_id"])
        config,design=load(source/"frozen_config.json"),load(source/"inherited_q2_design.json")
        cases={p.name.removesuffix(".json.gz"):unpack(p) for p in (source/"cases").glob("*.json.gz")}
        status=csv_read(source/"transition_case_status.csv")
        if len(cases)!=116 or len(status)!=116 or len({r["id"] for r in status})!=116:raise ValueError("Frozen experiment grid incomplete")
        check("all_frozen_grid_points_recorded",len(cases))
        counts=[]
        for key,value in cases.items():counts.append(dict(id=key,**audit_case(value,config,design)))
        check("annual_energy_carbon_cash_budget_lifetime_and_terminal_accounts",counts)
        check("continuous_events_same_services_and_restored_stocks",audit_events(source,config,cases))
        lock=load(source/"selection_lock.json")
        feasible=independently_screen(csv_read(source/"policy_results.csv"),config["policy"])
        if feasible!=sorted(lock["policy"]["feasible"]):raise ValueError("Independent feasible-policy set differs")
        check("designated_constraints_recomputed_without_relaxation",dict(feasible=feasible,selected=lock["policy"]["selected"]))
        comparisons=csv_read(source/"h01_comparisons.csv")
        fixed=[r for r in comparisons if r["mode"]=="fixed_projects" and r["status"]=="completed"]
        if any(r["fixed_capital_set_equal"]!="True" for r in fixed):raise ValueError("Fixed project comparison changed set")
        check("fixed_project_comparisons_are_actually_same_set",len(fixed))
        original_contracts=["data/sources.json","data/evidence_reviews.json","workflow/model_inputs.json"]
        original_contracts += [p.relative_to(ROOT).as_posix() for p in (ROOT/"只读工作区").iterdir() if p.is_file()]
        original_contracts += [p.name for p in ROOT.iterdir() if p.is_file() and p.suffix.lower() in {".xlsx",".pdf"}]
        for rel in original_contracts:
            content=subprocess.run(["git","show",config["base_sha"]+":"+rel],cwd=ROOT,capture_output=True,check=True).stdout
            if hashlib.sha256(content).hexdigest()!=sha(ROOT/rel):raise ValueError("Protected original changed: "+rel)
        check("protected_originals_equal_locked_base",len(original_contracts))
        if args.reproduction_root:
            reproduction=args.reproduction_root.resolve()
            if reproduction==ROOT:raise ValueError("Independent checkout required")
            for rel,expected in {**manifest["code_hashes"],**manifest["input_hashes"]}.items():
                if sha(reproduction/rel)!=expected:raise ValueError("Independent checkout input/code mismatch: "+rel)
            check("independent_checkout_has_identical_code_and_inputs",str(reproduction))
            env=os.environ.copy();env["PYTHONHASHSEED"]="1729"
            command=[sys.executable,"-B","-X","utf8","run.py","q3","--config",manifest["config_path"],"--output-dir","outputs/q3/p3_mmj_v3_reproduction"]
            log=target.with_suffix(".reproduction.log")
            started=time.perf_counter()
            with log.open("w",encoding="utf-8") as f:
                result=subprocess.run(command,cwd=reproduction,env=env,stdout=f,stderr=subprocess.STDOUT)
            if result.returncode:raise ValueError("Independent full entry failed; see reproduction log")
            rep=reproduction/"outputs/q3/p3_mmj_v3_reproduction"
            repeated=load(rep/"run_manifest.json")
            if repeated["status"]!="conditional_experiments_completed":raise ValueError("Independent receipt incomplete")
            if any(sha(rep/p)!=v for p,v in repeated["outputs"].items()):raise ValueError("Independent output hashes changed")
            check("independent_full_entry",dict(returncode=0,seconds=time.perf_counter()-started,pythonhashseed=1729,command=command,run_id=repeated["run_id"]))
            check("independent_all_scientific_outputs",compare_files(source,rep))
        verify_latest(source)
        record.update(status="author_round_passed",passed=True,
            scope="Conditional-computation audit only; empirical/Q2 scope limitations and C9 remain")
    except Exception as exc:
        record.update(status="failed",error=type(exc).__name__+": "+str(exc))
    save(target,record)
    print(json.dumps({k:record[k] for k in ("status","passed")}),flush=True)
    if not record["passed"]:print(record["error"],file=sys.stderr)
    return 0 if record["passed"] else 1


if __name__=="__main__":raise SystemExit(main())
