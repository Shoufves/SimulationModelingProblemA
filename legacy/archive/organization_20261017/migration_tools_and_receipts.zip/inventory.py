from pathlib import Path
import collections, hashlib, json, os

ROOT = Path(__file__).resolve().parents[2]
A = ROOT / 'A题'
OUT = Path(__file__).resolve().parent
records = []
dirs = collections.defaultdict(lambda: [0, 0])
for base, children, names in os.walk(A):
    for name in names:
        p = Path(base) / name
        rel = p.relative_to(A).as_posix()
        size = p.stat().st_size
        parts = p.relative_to(A).parts
        artifact = any(x in parts for x in ('.venv-workbench', '__pycache__', '.pytest_cache', '.git'))
        h = None
        if not artifact:
            with p.open('rb') as f:
                h = hashlib.file_digest(f, 'sha256').hexdigest()
        records.append(dict(path=rel, bytes=size, sha256=h, artifact=artifact))
        key = '/'.join(parts[:2]) if len(parts)>1 else parts[0]
        dirs[key][0] += 1
        dirs[key][1] += size
(OUT / 'before.json').write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding='utf-8')
groups = collections.defaultdict(list)
for r in records:
    if r['sha256']:
        groups[r['sha256']].append(r)
dupes = [v for v in groups.values() if len(v)>1]
(OUT / 'duplicates.json').write_text(json.dumps(dupes, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(files=len(records), bytes=sum(r['bytes'] for r in records), non_artifacts=sum(not r['artifact'] for r in records), duplicate_groups=len(dupes), duplicate_files=sum(len(v)-1 for v in dupes), duplicate_bytes=sum(sum(r['bytes'] for r in v[1:]) for v in dupes), directories=dirs), ensure_ascii=False, indent=2))
(OUT / 'files.txt').write_text('\n'.join(r['path'] for r in records if not r['artifact']), encoding='utf-8')
