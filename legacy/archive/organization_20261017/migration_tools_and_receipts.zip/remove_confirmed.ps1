$ErrorActionPreference = 'Stop'
$workspaceA = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../A题'))
$protectedA = Join-Path $workspaceA '只读工作区'
$deleteEntries = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'delete.json') -Raw -Encoding utf8 | ConvertFrom-Json
$resolvedEntries = @()
foreach ($entry in $deleteEntries) {
    $resolvedTarget = [IO.Path]::GetFullPath((Join-Path $workspaceA $entry.path))
    if (!$resolvedTarget.StartsWith($workspaceA + '\', [StringComparison]::OrdinalIgnoreCase) -or $resolvedTarget.StartsWith($protectedA + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Unsafe target: $resolvedTarget" }
    if (!(Test-Path -LiteralPath $resolvedTarget -PathType Leaf)) { throw "Missing planned source: $resolvedTarget" }
    if ($entry.sha256) {
        $actualHash = (Get-FileHash -LiteralPath $resolvedTarget -Algorithm SHA256).Hash
        if ($actualHash -ne $entry.sha256) { throw "Changed source: $resolvedTarget" }
    }
    $resolvedEntries += $resolvedTarget
}
foreach ($resolvedTarget in $resolvedEntries) { Remove-Item -LiteralPath $resolvedTarget -Force }
# Remove only empty old directories; never recursively remove a computed tree.
$oldTrees = @('A题_mmj', 'A题_lb', 'script', '分析整理')
foreach ($oldTree in $oldTrees) {
    $oldRoot = [IO.Path]::GetFullPath((Join-Path $workspaceA $oldTree))
    if (!$oldRoot.StartsWith($workspaceA + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe directory' }
    if (Test-Path -LiteralPath $oldRoot) {
        $oldDirs = @(Get-ChildItem -LiteralPath $oldRoot -Directory -Recurse -Force | Sort-Object { $_.FullName.Length } -Descending)
        foreach ($oldDir in $oldDirs) {
            if (!(Get-ChildItem -LiteralPath $oldDir.FullName -Force | Select-Object -First 1)) { Remove-Item -LiteralPath $oldDir.FullName -Force }
        }
        if (!(Get-ChildItem -LiteralPath $oldRoot -Force | Select-Object -First 1)) { Remove-Item -LiteralPath $oldRoot -Force }
    }
}
Write-Output "Removed $($resolvedEntries.Count) verified duplicate/generated files. Protected files untouched."
