"""Reviewed, hash-checked file-level migration. Never alters the protected directory."""
from pathlib import Path
import argparse, collections, csv, hashlib, json, os, shutil

ROOT = Path(__file__).resolve().parents[2]
A = ROOT / 'A题'
WORK = Path(__file__).resolve().parent
LB = 'A题_lb/A题完整资料包/'
LIB = LB + 'A题资料库/'
PACK = LB + '2026年第二届全国大学生仿真建模应用挑战赛赛题/'
TOPICS = [
    ('专项补查_20261017/替代与扩展_20261017/alternatives/', 'trade_alternatives'),
    ('专项补查_20261017/替代与扩展_20261017/employment/', 'employment'),
    ('专项补查_20261017/household_employment/', 'household'),
    ('专项补查_20261017/ai_trade/', 'ai_trade'),
    ('补充收集_20261017/international/', 'international'),
    ('补充收集_20261017/ai_social/', 'ai_social'),
]

def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def within(p):
    p = p.resolve()
    if not p.is_relative_to(A.resolve()) or p.is_relative_to((A/'只读工作区').resolve()):
        raise ValueError(f'Unsafe mutation: {p}')
    return p

def destination(r):
    s = r['path']; p = Path(s)
    if s.startswith('只读工作区/'):
        return s, 'protect', '只读方案原件，路径及字节不变'
    if r['artifact']:
        return '', 'delete_generated', '旧机器虚拟环境或Python缓存；依赖由requirements重建'
    if s.startswith('~$'):
        return 'archive/session_artifacts/'+p.name, 'archive', 'Excel锁文件可能对应未关闭会话，移出研究入口而不删除'
    if s.startswith(PACK):
        suffix = s[len(PACK):]
        if suffix.startswith(('B题/','C题/')):
            external = ROOT / suffix
            if not external.is_file() or sha(external) != r['sha256']:
                raise ValueError(f'Non-A file has no identical retained original: {s}')
            return '../'+suffix, 'external_duplicate', '与赛题根目录B/C原件一致；仅删除混入A题的副本'
        if suffix.startswith('A题/'):
            return suffix[3:], 'deduplicate', '保留A题根目录官方原件'
        return 'docs/competition/'+p.name, 'keep', '提交格式与规范仍是A题交付依据'
    if s.startswith('A题_mmj/'):
        tail = s[len('A题_mmj/'):]
        if tail.startswith('tmp/'):
            if p.suffix in ('.json', '.log') or p.name == 'browser-failure.png':
                return 'archive/diagnostics/mmj/'+tail[4:], 'archive', '保留独有调试记录与导出配置；不作正式结果'
            return '', 'delete_generated', '重复截图或可由源稿重建的PDF/手册排版预览'
        if tail in ('README.md','FILES.md','WORKFLOW.md'):
            return 'docs/history/mmj/'+tail, 'archive', '旧工作区总入口；统一入口替代，历史成果说明保留'
        return tail, 'keep', '复用模型、验证链、原始观测、局部结果及运行入口'
    if s.startswith('script/'):
        return 'scripts/'+s[7:], 'keep', 'yx离线处理/审计脚本；收集脚本保留，不自动联网'
    if s.startswith('分析整理/'):
        if p.suffix == '.md':
            return 'docs/design/'+p.name, 'keep', 'yx完整数学与实施规格是final依据'
        if p.suffix == '.json':
            return 'archive/audits/yx/'+p.name, 'archive', '原附件核查记录保留'
        return '', 'delete_generated', '题面页预览可由保留的赛题PDF重建'
    if s.startswith(LIB):
        tail=s[len(LIB):]
        topic='base'; rest=tail
        for pre, name in TOPICS:
            if tail.startswith(pre):
                topic=name; rest=tail[len(pre):]; break
        q=Path(rest)
        if q.suffix == '.py':
            return 'tools/legacy_lb/'+tail, 'keep', '原采集/处理代码；通过隔离重建入口恢复相对路径'
        if 'extracted_source_data/' in rest or q.name == 'household_energy_source_fig4.csv':
            return 'data/restricted/household/'+rest, 'restricted', '保留家庭级或潜在细粒度材料，不解析、不进入群体模型'
        for pre in ('raw/', 'originals/'):
            if rest.startswith(pre):
                return 'data/raw/lb/'+topic+'/'+rest[len(pre):], 'keep', '独有原件及来源证据，保留字节'
        for pre in ('data/', 'derived/'):
            if rest.startswith(pre):
                return 'data/processed/lb/'+topic+'/'+rest[len(pre):], 'keep', '保留来源、单位与用途边界；统一视图控制重复使用'
        if rest.startswith('extracted/'):
            return 'data/extracted/lb/'+rest[10:], 'keep', '离线原件文本提取，可定位原报告'
        if q.suffix=='.md':
            return 'docs/sources/lb/'+topic+'/'+rest, 'keep', '来源、口径、缺口说明；final为路线准则'
        if q.suffix=='.csv' and ('就业' in q.name):
            return 'data/processed/lb/'+topic+'/'+q.name, 'keep', '九省区与全国就业存量补充'
        return 'data/catalog/lb/'+topic+'/'+rest, 'keep', '来源清单、获取记录、核查与旧任务配置'
    if s.startswith(LB):
        return 'docs/history/lb/'+s[len(LB):], 'archive', '旧路线与讨论保留追溯，不与final并列'
    return s, 'keep', 'yx数据及官方原件，保持已用路径'

def plan():
    original=json.loads((WORK/'before.json').read_text(encoding='utf-8'))
    rows=[]
    for r in original:
        target, action, reason=destination(r)
        rows.append(dict(**r, target=target, action=action, reason=reason))
    # Every official file and original yx path is preferred. Versioned results
    # intentionally retain identical report text because their input manifests differ.
    candidates=collections.defaultdict(list)
    for r in rows:
        if r['target'] and r['action'] not in ('protect','external_duplicate'):
            candidates[r['sha256']].append(r)
    def preference(r):
        return (0 if r['path']==r['target'] else 1 if r['path'].startswith('A题_mmj/') else 2,
                1 if r['target'].endswith('.zip') else 0, len(r['target']), r['target'])
    for group in candidates.values():
        if len(group)<2: continue
        if all('/outputs/calibration/' in r['path'] for r in group): continue
        canonical=min(group,key=preference)
        for r in group:
            if r is canonical: continue
            r['target']=canonical['target'];r['action']='deduplicate'
            r['reason']='SHA256完全一致；唯一实体='+canonical['target']
    targets={}
    for r in rows:
        if r['target'] and r['action'] not in ('deduplicate','external_duplicate','protect'):
            if r['target'] in targets: raise ValueError(('collision',r,targets[r['target']]))
            targets[r['target']]=r
    (WORK/'plan.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(actions=collections.Counter(r['action'] for r in rows),
        deleted_bytes=sum(r['bytes'] for r in rows if r['action'] in ('deduplicate','delete_generated','external_duplicate')),
        destinations=collections.Counter(r['target'].split('/')[0] for r in rows if r['target'])),ensure_ascii=False,indent=2))
    return rows

def execute(rows):
    # Preconditions: every immutable source hash still matches the inspected snapshot.
    for r in rows:
        if r['sha256'] and sha(A/r['path'])!=r['sha256']:
            raise ValueError('Source changed since inspection: '+r['path'])
    audit=A/'archive/organization_20261017';audit.mkdir(parents=True,exist_ok=True)
    shutil.copy2(WORK/'before.json',audit/'before.json')
    shutil.copy2(WORK/'plan.json',audit/'file_disposition.json')
    # Move unique files first, without ever overwriting another file.
    for r in rows:
        if r['action'] in ('keep','archive','restricted') and r['path']!=r['target']:
            src=within(A/r['path']);dst=within(A/r['target'])
            if dst.exists(): raise FileExistsError(dst)
            dst.parent.mkdir(parents=True,exist_ok=True)
            src.rename(dst)
    # All useful source bytes must now resolve to their retained canonical location.
    for r in rows:
        if r['target']:
            p=(A/r['target']).resolve()
            if sha(p)!=r['sha256']: raise ValueError('Retention failed: '+r['path'])
    # Produce a finite reviewed deletion manifest. Actual deletion uses native PS.
    drops=[dict(path=r['path'],sha256=r['sha256'],reason=r['reason']) for r in rows
           if r['action'] in ('deduplicate','delete_generated','external_duplicate')]
    (WORK/'delete.json').write_text(json.dumps(drops,ensure_ascii=False,indent=2),encoding='utf-8')
    aliases={r['path']:r['target'] for r in rows if r['target']}
    catalog=A/'data/catalog';catalog.mkdir(parents=True,exist_ok=True)
    (catalog/'path_aliases.json').write_text(json.dumps(aliases,ensure_ascii=False,indent=2),encoding='utf-8')
    with (audit/'file_disposition.csv').open('w',encoding='utf-8-sig',newline='') as f:
        fields=['path','target','action','reason','bytes','sha256']
        w=csv.DictWriter(f,fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
    print('Unique files moved and all useful byte sequences verified. Native deletion manifest ready.')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--apply',action='store_true');args=ap.parse_args()
    rows=plan()
    if args.apply: execute(rows)
