"""Add navigation; retain original documents before repairing their links."""
from pathlib import Path
import hashlib, json, os, re, shutil, zipfile

BASE=Path(__file__).resolve().parents[2]
A=BASE/'A题'
AUDIT=A/'archive/organization_20261017'
mapping=json.loads((A/'data/catalog/path_aliases.json').read_text(encoding='utf-8'))
plan=json.loads((AUDIT/'file_disposition.json').read_text(encoding='utf-8'))
origin={r['target']:r['path'] for r in plan if r['target'] and r['action'] not in ('deduplicate','external_duplicate')}
LIB='A题_lb/A题完整资料包/A题资料库/'

for name in ('final_yx.md','final_mmj.md','final_lb.pdf'):
    p=A/'docs/history/comparison'/name;p.parent.mkdir(parents=True,exist_ok=True)
    if not p.exists():shutil.copy2(BASE/'最终文档-方案'/name,p)
p=A/'docs/history/innovation/final_innovate_idea.md';p.parent.mkdir(parents=True,exist_ok=True)
if not p.exists():shutil.copy2(BASE/'final_innovate_idea.md',p)

originals=AUDIT/'edited_originals.zip'
missing=[];edits=[]
special={'文档对比报告/finalyx.md':'docs/history/comparison/final_yx.md',
 '文档对比报告/finalmmj.md':'docs/history/comparison/final_mmj.md',
 '文档对比报告/两份方案评估与融合建议lb.pdf':'docs/history/comparison/final_lb.pdf'}

def locate(target,old,new):
    target=target.replace('\\','/').replace('%20',' ')
    if re.match(r'^(https?|mailto|app|codex):',target) or target.startswith('#'):return target
    anchor=''
    if '#' in target:target,anchor=target.split('#',1);anchor='#'+anchor
    candidates=[]
    if target.startswith('D:/CSF2026/sanzu/'):
        t=target[len('D:/CSF2026/sanzu/'):]
        if t.startswith('A题_yx/'): t=t[6:]
        elif t.startswith('A题mmj/'): t='A题_mmj/'+t[6:]
        elif t.startswith('A题lb/'):t='A题_lb/'+t[5:]
        candidates.append(special.get(t,t))
    for marker in ('A题资料库/','A题_mmj/','A题mmj/','A题_yx/','A题_yx(1)/'):
        if marker in target:
            pre=LIB if marker=='A题资料库/' else 'A题_mmj/' if 'mmj' in marker else ''
            candidates.append(pre+target.split(marker,1)[1])
    if '/A题/' in target:candidates.append(target.split('/A题/',1)[1])
    if not re.match(r'^[A-Za-z]:',target):
        candidates.extend([os.path.normpath(str(Path(old).parent/target)).replace('\\','/'),target])
    if target.endswith('/final.md'):candidates.append('只读工作区/final.md')
    if target.endswith('/gemini_final_idea.md'):candidates.append('只读工作区/gemini_final_idea.md')
    for candidate in candidates:
        dest=mapping.get(candidate,candidate)
        if (A/dest).exists():return os.path.relpath(A/dest,(A/new).parent).replace('\\','/')+anchor
        # Original directory references from the mmj workspace have one-to-one roots.
        if candidate.startswith('A题_mmj/') and (A/candidate[7:]).is_dir():
            return os.path.relpath(A/candidate[7:],(A/new).parent).replace('\\','/')+anchor
    # Unique filename lookup repairs original machine drive prefixes only when unambiguous.
    hits={v for k,v in mapping.items() if Path(k).name==Path(target).name and v and not v.startswith('../')}
    if len(hits)==1:
        dest=next(iter(hits))
        return os.path.relpath(A/dest,(A/new).parent).replace('\\','/')+anchor
    missing.append(dict(document=new,target=target))
    return target+anchor

def repair(text,old,new):
    def link(m):
        target=m.group(2)
        dest=locate(target,old,new)
        return m.group(1)+'<'+dest+'>)'
    text=re.sub(r'(\]\()<?([^\n<>]*?)>?\)',link,text)
    def ref(m):return m.group(1)+'<'+locate(m.group(2),old,new)+'>'
    return re.sub(r'(^\[[^\]]+\]:\s*)<([^>]+)>',ref,text,flags=re.M)

with zipfile.ZipFile(originals,'a',compression=zipfile.ZIP_DEFLATED) as z:
    names=set(z.namelist())
    for p in sorted((A/'docs').rglob('*.md')):
        new=p.relative_to(A).as_posix()
        if new in ('docs/final_阅读版.md','docs/gemini_final_idea_阅读版.md'):continue
        if new.startswith('docs/history/comparison/'):continue
        old=origin.get(new,new)
        text=z.read(new).decode('utf-8-sig') if new in names else p.read_text(encoding='utf-8-sig')
        updated=repair(text,old,new)
        if text!=updated:
            if new not in names:z.write(p,new);names.add(new)
            p.write_text(updated,encoding='utf-8')
            edits.append(new)
    # Only relocate the audit outputs and documentation paths. The numerical code is unchanged.
    for name,replacements in {
      'audit_attachments.py': [('ROOT / "分析整理" / "附件数据核查.json"','ROOT / "outputs" / "attachments" / "yx_附件数据核查.json"')],
      'audit_data_package.py': [('ROOT / "script"','ROOT / "scripts"'),('ROOT / "分析整理"','ROOT / "docs/design"'),('ROOT / "分析整理/A题内容分析与数据准备清单.md"','ROOT / "docs/design/A题内容分析与数据准备清单.md"')],
    }.items():
        p=A/'scripts'/name;rel=p.relative_to(A).as_posix()
        if rel not in names:z.write(p,rel);names.add(rel)
        text=p.read_text(encoding='utf-8')
        for before,after in replacements:text=text.replace(before,after)
        p.write_text(text,encoding='utf-8');edits.append(rel)
    for p in (A/'prompts').glob('*.md'):
        rel=p.relative_to(A).as_posix()
        if rel not in names:z.write(p,rel);names.add(rel)
        text=p.read_text(encoding='utf-8')
        prefix='> 统一工作区执行约束：先读 `只读工作区/final.md` 与 `docs/IMPLEMENTATION_ROADMAP.md`。本文为原mmj阶段提示，仅复用核验流程；历史基年/窗口、情景编号及研究优先级以final为准（2024候选初态，2015—2021训练、2022—2024已接触留出；S0/SP/SG/ST后接SW/SGW；H01/H02优先）。gemini创新仅在基础验收后启用，缺失输入不得填零。\n\n'
        if not text.startswith('> 统一工作区执行约束：'):p.write_text(prefix+text,encoding='utf-8');edits.append(rel)

for name in ('final','gemini_final_idea'):
    old='只读工作区/'+name+'.md';new='docs/'+name+'_阅读版.md'
    text=(A/old).read_text(encoding='utf-8')
    updated=repair(text,old,new)
    # Match explicit comparison references by their ids, independently of legacy paths.
    if name=='final':
        for key,dest in [('RY','final_yx.md'),('RM','final_mmj.md'),('RL','final_lb.pdf')]:
            updated=re.sub(r'^\['+key+r'\]:.*$',f'[{key}]: <history/comparison/{dest}>',updated,flags=re.M)
    banner=f'> 导航副本：仅适配文件链接，研究内容以[只读原文](../只读工作区/{name}.md)为准。原文SHA256：`{hashlib.sha256((A/old).read_bytes()).hexdigest()}`。整理未改变研究结论或准入状态。\n\n'
    (A/new).write_text(banner+updated,encoding='utf-8')

(AUDIT/'document_link_repairs.json').write_text(json.dumps(dict(edited=edits,unresolved=missing),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(edited_documents=len(edits),unresolved_links=len(missing)),ensure_ascii=False))
