# Independent diagnosis after the first 2741-candidate run

Read-only production-code inspection and independent replay of its training-selected best:

`activity_elasticity=-0.75, oil_activity_elasticity=1.1, gas_activity_elasticity=2, replacement_adoption=0`.

## Directly reproduced discrepancies

| Year | Model gas TWh | Observed gas TWh | Model biomass TWh | Observed biomass TWh |
|---|---:|---:|---:|---:|
| 2015 | 0 | 166.91 | 0 | 54.07 |
| 2021 | 0 | 287.10 | 0 | 166.00 |
| 2024 | 0 | 320.72 | 0 | 208.50 |

2024 generation: model 9656.99 TWh versus observed 10086.88 TWh.
2024 covered clean generation: model 3475.05 TWh versus observed 3849.68 TWh.
Despite the lower total, coal generation is 6.08% above observation.
During 2015-2021, coal generation is 12.56%-18.19% above observation.

2024 total primary consumption is 94.41% of observation.
Coal consumption is 87.60%, oil is 112.77%, and gas is 110.42%.
Share residuals are coal -3.84 pp, oil +3.54 pp, gas +1.49 pp.
Thus low total consumption also increases the apparent oil/gas share errors.

## Diagnostic separation of power and other fuel use

Using the same declared fixed efficiencies as the model, a diagnostic can subtract observed fuel-specific generation input from observed statistical fuel consumption:

`approximate_nonpower_tce = published_total_tce * published_fuel_share - observed_fuel_generation_MWh / model_efficiency / TCE_MWH`

This is not observed final consumption. It includes feedstock and unseparated transformation/boundary differences and depends on the assumed constant efficiency.

| Year | Coal, billion tce | Oil, billion tce | Gas, billion tce |
|---|---:|---:|---:|
| 2014 | 1.5592 | 0.7295 | 0.2084 |
| 2021 | 1.3264 | 0.9686 | 0.3942 |
| 2024 | 1.4248 | 1.0560 | 0.4487 |

Coal's approximate nonpower input falls during training but rises during evaluation.
The model's 2024 nonpower coal residual is only 64.96% of this diagnostic observation.
A negative demand elasticity has a real training-period motivation, but must also compensate for the model's excess coal generation.

## Implication for the proposed saturation revision

A finite-horizon elasticity transition is a plausible reduced-form alternative to perpetual historical trend extrapolation. It is not established as a physical equipment mechanism merely because its time constant equals equipment lifetime. Existing equipment cohorts already implement actual stock renewal.

The proposal should retain the previous model, select parameters using training loss, disclose that model structure was revised after evaluation was seen, and test the transition horizon. Do not claim independent validation or causal identification.

The observed dispatch omission is a separate mechanism limitation: gas and biomass production disappear under the present homogeneous merit-order electricity optimization. Do not fabricate minimum-run shares to force agreement. A fuller repair would need defensible heat/CHP, spatial/temporal or service constraints; otherwise report the per-technology generation residuals and retained scientific limitation.
