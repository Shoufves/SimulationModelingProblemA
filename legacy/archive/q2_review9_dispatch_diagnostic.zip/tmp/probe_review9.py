import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.run_q2_national import preflight,calibrate,evaluate,dump

if __name__=='__main__':
    out=ROOT/'tmp/review9_training';out.mkdir(exist_ok=True)
    data,design,_=preflight()
    dump(out/'frozen_design.json',design)
    result=calibrate(data,design,out)
    evaluate(data,design,result,out)
    print(result['best'],flush=True)
    print(result['quality']['acceptance'],flush=True)
