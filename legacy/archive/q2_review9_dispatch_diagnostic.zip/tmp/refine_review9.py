import sys,json
from pathlib import Path
from itertools import product
from concurrent.futures import ProcessPoolExecutor
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.run_q2_national import preflight,calibration_trial,NationalModel,loss
if __name__=='__main__':
 data,design,_=preflight()
 old=json.loads((ROOT/'outputs/q2/p2_lb_national/calibration.json').read_text())
 base=old['best']['parameters']
 combinations=list(product([-.875,-.75,-.625,-.5,-.375],[.8,.85,.9,.95,1,1.05,1.1],[1.5,1.625,1.75,1.875,2]))
 payloads=[(i,{**base,'activity_elasticity':c,'oil_activity_elasticity':o,'gas_activity_elasticity':g},data,design) for i,(c,o,g) in enumerate(combinations)]
 with ProcessPoolExecutor(max_workers=4) as pool:trials=list(pool.map(calibration_trial,payloads,chunksize=5))
 best=min((r for r in trials if r['loss'] is not None),key=lambda r:r['loss'])
 model=NationalModel(data,design,best['parameters'],2014,detail=False).run(2024)
 value,parts,_=loss(model.paths,data,design,design['evaluation_years'],'fine_grid_training_selected')
 result=dict(best=best,training_trials=trials,evaluation_loss=value,evaluation_parts=parts)
 (ROOT/'tmp/review9_refine.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(best,flush=True);print(parts,flush=True)
