import sys,json,math
from pathlib import Path
from itertools import product
from concurrent.futures import ProcessPoolExecutor
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.run_q2_national import preflight,calibration_trial,NationalModel,loss

def fuel_elasticity(self,fuel,year):
    initial=self.theta.get(fuel+'_activity_elasticity',self.theta['activity_elasticity'])
    terminal=self.a['fuel_terminal_activity_elasticity'][fuel]
    mix=1-math.exp(-max(0,year-2014)/self.a['device_lifetime_years'])
    return initial*(1-mix)+terminal*mix
NationalModel.fuel_elasticity=fuel_elasticity

if __name__=='__main__':
 data,design,_=preflight()
 base=json.loads((ROOT/'outputs/q2/p2_lb_national/calibration.json').read_text())['best']['parameters']
 combinations=list(product([-1.25,-1,-.75,-.5,-.25],[.8,.95,1.1,1.25,1.4],[1.75,2,2.25,2.5,2.75]))
 payloads=[(i,{**base,'activity_elasticity':c,'oil_activity_elasticity':o,'gas_activity_elasticity':g},data,design) for i,(c,o,g) in enumerate(combinations)]
 with ProcessPoolExecutor(max_workers=4) as pool:trials=list(pool.map(calibration_trial,payloads,chunksize=5))
 best=min((r for r in trials if r['loss'] is not None),key=lambda r:r['loss'])
 model=NationalModel(data,design,best['parameters'],2014,detail=False).run(2024)
 value,parts,_=loss(model.paths,data,design,design['evaluation_years'],'saturating_training_selected')
 result=dict(best=best,trials=trials,evaluation_loss=value,evaluation_parts=parts)
 (ROOT/'tmp/review9_saturation_fine.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(best,flush=True);print(parts,flush=True)
